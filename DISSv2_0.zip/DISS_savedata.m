function DISS_savedata(YY,MM,DD,hh,mm,ss,Scaled,fH,statname,iontype,Scalername)
    s=filesep;
    %Scaled data (text files)
    if exist([pwd s 'Scaled'],'dir')~=7
        mkdir([pwd s 'Scaled'])
    end
    if exist([pwd s 'Scaled' s YY],'dir')==0
        mkdir([pwd s 'Scaled' s YY]);
    end
    if exist([pwd s 'Scaled' s YY s MM],'dir')==0
        mkdir([pwd s 'Scaled' s YY s MM]);
    end
    
    %Scaled Data (For DISS)
    if exist([pwd s 'Internaldata'],'dir')~=7
        mkdir([pwd s 'Internaldata'])
    end
    if exist([pwd s 'Internaldata' s YY],'dir')==0
        mkdir([pwd s 'Internaldata' s YY]);
    end
    if exist([pwd s 'Internaldata' s YY s MM],'dir')==0
        mkdir([pwd s 'Internaldata' s YY s MM]);
    end
    
    Datapath=[pwd s 'Scaled' s YY s MM s];
    Datapath2=[pwd s 'Internaldata' s YY s MM s];
    
    %Saving data in .mat to reuse it 
    save([Datapath2 statname YY MM DD '.mat'],'Scaled');
    
    Datatime=table(hh,mm,ss,'VariableNames',{'hh','mm','ss'});
    Dframe=struct2table(Scaled);
    Dataframe=[Datatime Dframe];
    
    %First, variables
    varaux=fieldnames(Dataframe);
    Listvar=varaux(1:end-3); L_form=Listvar;
    
    Listvar=string(Listvar');
    Listvar=strjoin(Listvar); %h9=strrep(Listvar,' ',',');
    Listvar=strrep(Listvar,' ','(it,:),');
    %Second, format
    for indx=4:length(L_form)
       ind=indx-3;
       var_sel=L_form{indx};
       eval([var_sel '=Scaled.' var_sel ';']);
       switch var_sel(1)
           case 'f'
               form(ind)="%5.2f";
           case 'M'
               form(ind)="%5.2f";
           case 'q'
               form(ind)="%2s";
           case 'h'
               form(ind)="%6.2f";
           case 'T'
               switch var_sel(2)
                   case 'y'
                       form(ind)="%5s";
                   case 'E'
                       form(ind)="%8.3f";
               end
       end
    end
    
    Format=char(strjoin(form));
    Format=['%2s %2s %2s ' Format];
    %Format=strrep(Format,' ',',');
    %Third, headerlines
    switch iontype
        case 'DIGIPS42'
            iontype='DIGION';
        case 'IPS42'
            iontype='Camera IPS-42';
        case 'analogic'
            iontype='Camera ionogram';
    end
    
    h1=['% DISS data scaled from ' statname ' station. Last time modified: ' date '. Scaled by :' Scalername];
    h2=['% Ionogram type: ' iontype];
    h3=['% fH = ' num2str(fH,'%3.2f')];
    
    header1=strsplit(string([h1,'~',h2,'~',h3]),'~')';
    
    h1='% Columns 1 to 3                     : Hour,Minute,Second.';
    h2='% Columns 4,6                        : fmin,fxI';
    h3='% Columns 8,10,11,13,15              : fminEs,ftEs,fbEs,h''Es,Type Es';
    h4='% Columns 16,18,20,22,24             : fminE,foE,h''E,foE2,h''E2';
    h5='% Columns 26,28,30,32,34,36,38,40,42 : fminF,foF1,h''F/F1,M(3000)F1,';
    h6='%                                      foF/F2,h''F2,M(3000)F/F2,foF3,h''F3';
    h7='% Columns 44,45                      : hmF2, TEC (from POLAN)';
    h8='% (Qualifying/Descriptive letters are next to the respective parameter)';
    
    auxh=[h1,'~',h2,'~',h3,'~',h4,'~',h5,'~',h6,'~',h7,'~',h8,'~','% '];
    
    header2=strsplit(string(auxh),'~')';
    
    %Fourth, open text archive and save results
    fid=fopen([Datapath statname YY MM DD '.dat'],'wt');
    fprintf(fid,'%s\n',header1);
    fprintf(fid,'%s\n',header2);
    
    for it=1:length(hh)
        eval(['fprintf(fid,''' Format '\n'',' char(Listvar) '(it,:));']);
    end
    
    fclose(fid);
end