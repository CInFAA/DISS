function indx=fndnrst1D(vect,val)
    [~,indx]=min(abs(vect-val));
end