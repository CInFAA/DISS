function [RH,F,hmF2,TEC]=DISS_runpolan(Strdata,f,h,name,fH,dip,statname,scale)
    s=filesep;
    %E layer
    if isfield(Strdata,'E') && ~isempty(Strdata.E)
        f_E=f(round(Strdata.E(:,1)));
        h_E=h(round(Strdata.E(:,2)));
    else
        f_E=[];
        h_E=[];
    end
    %F layer
    if isfield(Strdata,'F') && ~isempty(Strdata.F)
        f_F=f(round(Strdata.F(:,1)));
        h_F=h(round(Strdata.F(:,2)));
    else
        f_F=[];
        h_F=[];
    end
    if isfield(Strdata,'F2') && ~isempty(Strdata.F2)
        f_F2=f(round(Strdata.F2(:,1)));
        h_F2=h(round(Strdata.F2(:,2)));
    else
        f_F2=[];
        h_F2=[];
    end
    
    h_polan=[h_E'; h_F'; h_F2'];
    f_polan=[f_E'; f_F'; f_F2'];
    
    if strcmp(scale,'exp')
       indxl=find(f_polan<4);
       step=1.5;
       h_polan=h_polan([indxl(round(1:step:end));(indxl(end):length(h_polan))']);
       f_polan=f_polan([indxl(round(1:step:end));(indxl(end):length(f_polan))']);
    end
    
    file = fopen([pwd s 'POLAN' s 'polanin.dat'],'wt');
    
    if isempty(str2num(name(14:15)))
       name(14:15)='00'; 
    end
    
    fprintf(file,'%s\n',['Chapman Layer, E + F.    ' num2str(-fH,'%3.2f') ' '...
        num2str(dip,'%3.1f') '   0.   0.    0']);
    fprintf(file,'%3s freq ',name(10:15));
    if length(f_polan)<31
        fprintf(file,'%5.2f ', f_polan);
    elseif length(f_polan)<51
        fprintf(file,'%5.2f ', f_polan(round(1:(length(f_polan)/31):end)));
    else
        fprintf(file,'%5.2f ', f_polan(round(1:(length(f_polan)/51):end)));
    end
    fprintf(file,'\n');
    
    
    fprintf(file,'%3s hprime ',name(10:15));
    if length(f_polan)<31
        fprintf(file,'%5.2f ', h_polan);
    elseif length(f_polan)<51
        fprintf(file,'%5.1f ', h_polan(round(1:(length(f_polan)/31):end)));
    else
        fprintf(file,'%5.1f ', h_polan(round(1:(length(f_polan)/51):end)));
    end
    fprintf(file,'\n\n\n-9');
    
    fclose(file);
    %% This needs to be changed in each computer
    wine32='/usr/lib/wine/wineserver32';
    [~,~]=system(wine32);
    [~,result] = system(['cd ' pwd '/POLAN/ && /usr/lib/wine/wine polan.exe polanin.dat']);
    polan_rslt=[];
    try
        indx=strfind(result,'0.50');
        result=result(indx(1)-4:end);
        res=strsplit(result,'\n');
        for i=1:length(res)
            polan_rslt=[polan_rslt;res{i}];
        end
        polan_rslt = str2num(polan_rslt);
    catch
        polan_rslt=[];
    end
    %%
    if exist([pwd s 'Polan_Data'],'dir')~=7
        mkdir([pwd s 'Polan_Data'])
    end
    if exist([pwd s 'Polan_Data' s name(1:4)],'dir')==0
        mkdir([pwd s 'Polan_Data' s name(1:4)]);
    end
    if exist([pwd s 'Polan_Data' s name(1:4) s name(5:6)],'dir')==0
        mkdir([pwd s 'Polan_Data' s name(1:4) s name(5:6)]);
    end
    if exist([pwd s 'Polan_Data' s name(1:4) s name(5:6) s name(7:8)],'dir')==0
        mkdir([pwd s 'Polan_Data' s name(1:4) s name(5:6) s name(7:8)]);
    end

    if size(polan_rslt)==0
        F = [];
        RH = [];
        hmF2 = NaN;
        TEC = NaN;
    else
        F = polan_rslt(:,1);
        RH = polan_rslt(:,2);
        [N_top,indx]=DISSTopside(F,RH,name,statname);
        hmF2=RH(indx);
        N_top=N_top';
        h_top=RH(indx):10:1000;
        h_top=h_top';
        F(indx:end)=[]; RH(indx:end)=[];
        F=[F;N_top];
        RH=[RH;h_top];
        FH_id=fopen([pwd s 'Polan_Data' s name(1:4) s name(5:6) s name(7:8)...
            s statname 'prof' name(1:15) '.dat'],'w');
        for i3=1:length(F)
            fprintf(FH_id,'%3.2f %3.2f\n',F(i3),RH(i3));
        end
        TEC = trapz(1.24.*(F.^2)); %Change it...
    end
end