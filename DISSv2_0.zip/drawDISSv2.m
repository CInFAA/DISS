function drawDISSv2(fig,X,Y,lim1,lim2,colordraw)
stepdraw=2;
set(fig,'WindowButtonDownFcn',{@start})
    function start(~,~)
        global R
        ct=get(fig,'selectiontype');
        switch ct
            case 'normal'
                if exist('R','var')
                    delete(R)
                end
                C=get(gca,'CurrentPoint');
                xx=round(C(1,1));
                yy=round(C(1,2));
                if round(xx/stepdraw)<1 || round(yy/stepdraw)<1
                    return;
                end
                X(round(xx/stepdraw))=xx;
                Y(round(xx/stepdraw))=yy;
                R=line(X,Y,'Color',colordraw,'LineWidth',3);
                set(fig,'WindowButtonMotionFcn',@drawing)
                set(fig,'WindowButtonUpFcn',{@enddraw})
            case 'alt'
                if exist('R','var')
                    delete(R)
                end
                C=get(gca,'CurrentPoint');
                xx=round(C(1,1));
                X(round(xx/stepdraw))=NaN;
                Y(round(xx/stepdraw))=NaN;
                R=line(X,Y,'Color',colordraw,'LineWidth',3);
                set(fig,'WindowButtonMotion',{@deldrawing})
                set(fig,'WindowButtonUpFcn',{@enddraw})
        end
    end
    function drawing(~,~)
        global R
        C=get(gca,'CurrentPoint');
        xx=round(C(1,1));
        yy=round(C(1,2));
        X(round(xx/stepdraw))=xx;
        Y(round(xx/stepdraw))=yy;
        set(R,'XData',X,'YData',Y)
    end
    function deldrawing(~,~)
        global R
        C=get(gca,'CurrentPoint');
        xx=round(C(1,1));
        X(round(xx/stepdraw))=NaN;
        Y(round(xx/stepdraw))=NaN;
        set(R,'XData',X,'YData',Y)
    end
    function enddraw(~,~)
        global R
        set(fig,'WindowButtonMotionFcn','')
        set(fig,'WindowButtonUpFcn','')
        X(X<lim1)=NaN; X(X>lim2)=NaN;
        Y(X<lim1)=NaN; Y(X>lim2)=NaN;
        set(R,'XData',X,'YData',Y)
    end
end