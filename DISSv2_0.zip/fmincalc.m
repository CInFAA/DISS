function [fmin,qdfmin]=fmincalc(D,i)
    minvect=[D.fminEs(i),D.fminE(i),D.fminF(i)];
    qdminvect=[D.qdfminEs(i,:);D.qdfminE(i,:);D.qdfminF(i,:)];
    [fmin,indx]=min(minvect);
    if isnan(fmin)
        qdfmin=qdminvect(3,:);
    else
        qdfmin=qdminvect(indx,:);
    end
end