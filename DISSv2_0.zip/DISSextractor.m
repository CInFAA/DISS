function [Scaled,ts]=DISSextractor(YY,MM,DD,stat)
datearch=[num2str(YY) num2str(MM,'%02d') num2str(DD,'%02d')];
Format=['%2c%2c%2c%5c%2c%5c%2c%5c%2c%5c%5c%2c%6c%2c%5c'...
 '%5c%2c%5c%2c%6c%2c%5c%2c%6c%2c%5c%2c%5c%2c'...
 '%6c%2c%5c%2c%5c%2c%6c%2c%5c%2c%5c%2c%6c%2c'...
 '%6c%8c'];
arch=[pwd '/Scaled/' num2str(YY) '/' num2str(MM,'%02d') '/' stat datearch '.dat'];
fid=fopen(arch);
T=textscan(fid,Format,'HeaderLines',12,'Delimiter',' ');

for i=[4:2:10 11:2:13 16:2:42 44:45]
   T{i}=str2num(T{i});
end

VariablesMain={'fmin','qdfmin','fxI','qdfxI'};
VariablesEslayer={'fminEs','qdfminEs','ftEs','fbEs','qdfbEs','hEs',...
    'qdhEs','TypeEs'};
VariablesElayer={'fminE','qdfminE','foE','qdfoE','hE','qdhE','foE2',...
    'qdfoE2','hE2','qdhE2'};
VariablesFlayer={'fminF','qdfminF','foF1','qdfoF1','hF','qdhF','M3000F1'...
    ,'qdM3000F1','foF','qdfoF','hF2','qdhF2','M3000F','qdM3000F'};
VariablesFlayerb={'foF3','qdfoF3','hF3','qdhF3'};
VariablesProf={'hmF2','TEC'};
Vars=cat(2,VariablesMain,VariablesEslayer,VariablesElayer,VariablesFlayer,...
    VariablesFlayerb,VariablesProf);
ts=datetime(YY,MM,DD,str2num(T{1}),str2num(T{2}),str2num(T{3}));
Scaled=cell2struct(T(4:end),Vars,2);
end
