Digitized Ionogram Scaling Script v 2.0

To ionogram reduction of LISN data (VIPIR):

In MATLAB:
1) Use LISNext.m to extract the data.
2) Use Tuc2DISS.m to give each ionogram the proper format.
3) Execute DISS_v2.m and select the "LISN OX Image" option.
4) Select "Browse..." or write manually the directory where is the "Data" folder.
5) Select the year, month and day.
6) Press Start and scale!

WARNING:
To use POLAN, there's some code lines that needs to be changed in "DISS_runpolan.m" to execute the POLAN.exe part.
"DISSTopside.m" uses the output of the model of Li 2019 (https://doi.org/10.1029/2018JA026286), using the coordinates
of the station and the corresponding F10.7 value. That output must be saved in a folder with the name of the station
selected. Commenting from line 105 to 112 avoid the Topside alpha-Chapman model and only saves the POLAN output.

To scale:

Each cursor is draggable with the mouse. However, it also allows to use the left/right keys to move them.

Controls:
E: Activate the E region frequency cursors. Presing a second time, it activates
the E2 cursor. The third time it'll deactivate all E region cursors.

F: Same as "E" but for F region. Presing a second time, it activates the F1 cursor (and M(3000)F1
if it's activated). The third time it'll deactivate all F region cursors.

M: Activates the M(3000)F/M(3000)F1 cursor when F region cursors are activated. Also deactivate them
when is pressed again.

S: Activate the E sporadic region frequency cursors. The ftEs cursor also asks about Type Es
and fbEs value (based on other variables) and their respective Q/D letters when "Enter" is pressed.
Also deactivate them when is pressed again.

G: Change the gyrofrequency.

H: Activate height mode. Here, you need to draw with your mouse a trace that follows the ordinary mode
of each layer. Only the activated cursors will be counted in this mode and it'll deactivate the draggable
feature. You can only draw between the fmin and the fo of each layer (except for E2 and F2 layers, which starts from
foE and foF1 respectively). The minimum point of each trace will be counted as the h' value. (Similarly to SAO X).

A message box will pop up, asking about the dip (it has to be positive, even when it's negative) and the station name
to select the Scale Height and name the profiles. Pressing "Cancel" will cause that POLAN won't run, but it'll always ask
after drawing.

Intro: Save the cursor numerical data selected (the upper right corner shows which) asking the Qualifying/Descriptive letters.

delete: Similar to "Intro", but it won't save numerical data, only the letters.

Left/Right arrows: Move the selected cursor.

Space: Change between cursors

When the figure is closed, it'll ask if you want to save or not. It won't close the figure (in the majority of the cases) until you
respond the dialog interface. Pressing 'Cancel' won't close the figure.



