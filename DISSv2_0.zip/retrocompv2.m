function retrocompv2(path,date,version,fH,scalername,statname)
switch version
    case '1.0.0'
        iontype='DIGIPS42';
        [YY,MM,DD]=datevec(date);
        YY=num2str(YY); MM=num2str(MM,'%02d'); DD=num2str(DD,'%02d');
        f_Sc=fopen([path filesep YY(3:4) MM DD '.dat']);
        Dat=textscan(f_Sc,'%2d%3d%5.2f%5.2f%5.2f%5.2f%5.2f%6.2f%6.2f%6.2f%5.2f','HeaderLines',2);
        Dat_l=importdata([path filesep YY(3:4) MM DD '_letters.dat']);
        for i=3:length(Dat_l)
            F(i-2,:)=strsplit(char(Dat_l{i}),',');
        end
        Dat_l=string(F);
        %General parameters
        Scaled.fmin=Dat{1,6};
        Scaled.qdfmin=char(Dat_l(:,5)); Scaled.qdfmin=Scaled.qdfmin(:,3:4);
        Scaled.fxI=NaN(length(Dat{1,1}),1);
        Scaled.qdfxI=repmat('  ',length(Dat{1,1}),1);
        %Es layer
        Scaled.fminEs=NaN(length(Dat{1,1}),1);
        Scaled.qdfminEs=repmat('  ',length(Dat{1,1}),1);
        Scaled.ftEs=Dat{1,7}; 
        Scaled.fbEs=NaN(length(Dat{1,1}),1);
        Scaled.qdfbEs=repmat('  ',length(Dat{1,1}),1);
        Scaled.hEs=NaN(length(Dat{1,1}),1);
        Scaled.qdhEs=repmat('  ',length(Dat{1,1}),1);
        Scaled.TypeEs=repmat('     ',length(Dat{1,1}),1);
        %E layer
        Scaled.fminE=NaN(length(Dat{1,1}),1); 
        Scaled.qdfminE=repmat('  ',length(Dat{1,1}),1);
        Scaled.foE=Dat{1,3}; 
        Scaled.qdfoE=char(Dat_l(:,2)); Scaled.qdfoE=Scaled.qdfoE(:,3:4);
        Scaled.hE=Dat{1,8};
        Scaled.qdhE=char(Dat_l(:,6)); Scaled.qdhE=Scaled.qdhE(:,3:4);
        Scaled.foE2=NaN(length(Dat{1,1}),1); Scaled.qdfoE2=repmat('  ',length(Dat{1,1}),1);
        Scaled.hE2=NaN(length(Dat{1,1}),1); Scaled.qdhE2=repmat('  ',length(Dat{1,1}),1);
        %F layer
        Scaled.fminF=NaN(length(Dat{1,1}),1);
        Scaled.qdfminF=repmat('  ',length(Dat{1,1}),1);
        Scaled.foF1=Dat{1,5};
        Scaled.qdfoF1=char(Dat_l(:,4)); Scaled.qdfoF1=Scaled.qdfoF1(:,3:4);
        Scaled.hF=Dat{1,9};
        Scaled.qdhF=char(Dat_l(:,7)); Scaled.qdhF=Scaled.qdhF(:,3:4);
        Scaled.M3000F1=NaN(length(Dat{1,1}),1);
        Scaled.qdM3000F1=repmat('  ',length(Dat{1,1}),1);
        Scaled.foF=Dat{1,4}; 
        Scaled.qdfoF=char(Dat_l(:,3)); Scaled.qdfoF=Scaled.qdfoF(:,3:4);
        Scaled.hF2=Dat{1,10};
        Scaled.qdhF2=char(Dat_l(:,8)); Scaled.qdhF2=Scaled.qdhF2(:,3:4);
        Scaled.M3000F=Dat{1,11};
        Scaled.qdM3000F=char(Dat_l(:,9)); Scaled.qdM3000F=Scaled.qdM3000F(:,3:4);
        Scaled.foF3=NaN(length(Dat{1,1}),1);
        Scaled.qdfoF3=repmat('  ',length(Dat{1,1}),1);
        Scaled.hF3=NaN(length(Dat{1,1}),1);
        Scaled.qdhF3=repmat('  ',length(Dat{1,1}),1);
        %POLAN
        Scaled.hmF2=NaN(length(Dat{1,1}),1); Scaled.TEC=NaN(length(Dat{1,1}),1);
        %Hour Minute Second
        hh=num2str(Dat{1,1},'%02d'); mm=num2str(Dat{1,2},'%02d'); ss=num2str(zeros(length(Dat{1,1}),1),'%02d');
    case '1.2.0'
        iontype='IPS42';
        dat=datestr(date,'yyyymmdd');
        YY=datestr(date,'yyyy'); MM=datestr(date,'mm'); DD=datestr(date,'dd');
        [ts,Scaled,qd]=DISSext(dat);
        VariablesMain={'fmin','qdfmin','fxI','qdfxI'};
        VariablesEslayer={'fminEs','qdfminEs','ftEs','fbEs','qdfbEs','hEs',...
            'qdhEs','TypeEs'};
        VariablesElayer={'fminE','qdfminE','foE','qdfoE','hE','qdhE','foE2',...
            'qdfoE2','hE2','qdhE2'};
        VariablesFlayer={'fminF','qdfminF','foF1','qdfoF1','hF','qdhF','M3000F1'...
            ,'qdM3000F1','foF','qdfoF','hF2','qdhF2','M3000F','qdM3000F'};
        VariablesFlayerb={'foF3','qdfoF3','hF3','qdhF3'};
        VariablesProf={'hmF2','TEC'};
        Vars=cat(2,VariablesMain,VariablesEslayer,VariablesElayer,VariablesFlayer,...
            VariablesFlayerb,VariablesProf);
        for f=1:length(fieldnames(qd))
            fd=fieldnames(qd);
            if strcmp(fd{f},'TypeEs')
                TEs=qd.(fd{f})(:,1:5);
                for i1=1:length(TEs)
                    aux2=~isspace(TEs(i1,:));
                    aux=length(TEs(i1,aux2));
                    switch aux
                        case 1
                            Scaled.(fd{f})(i1,:)=['    ' upper(TEs(i1,aux2))];
                        case 2
                            Scaled.(fd{f})(i1,:)=['   ' upper(TEs(i1,aux2))];
                        case 3
                            Scaled.(fd{f})(i1,:)=['  ' upper(TEs(i1,aux2))];
                        case 4
                            Scaled.(fd{f})(i1,:)=[' ' upper(TEs(i1,aux2))];
                        case 5
                            Scaled.(fd{f})(i1,:)=upper(TEs(i1,aux2));
                        otherwise
                            Scaled.(fd{f})(i1,:)='     ';
                    end
                end
           elseif strcmp(fd{f},'qdM3000')
               Scaled.([fd{f} 'F'])=qd.(fd{f});
           else
               Scaled.(fd{f})=qd.(fd{f});
           end
        end
        %New parameters
        Scaled.fxI=NaN(length(ts),1);
        Scaled.qdfxI=repmat('  ',length(ts),1);
        Scaled.fminEs=NaN(length(ts),1);
        Scaled.qdfminEs=repmat('  ',length(ts),1);
        Scaled.fminE=NaN(length(ts),1);
        Scaled.qdfminE=repmat('  ',length(ts),1);
        Scaled.foE2=NaN(length(ts),1);
        Scaled.qdfoE2=repmat('  ',length(ts),1);
        Scaled.hE2=NaN(length(ts),1);
        Scaled.qdhE2=repmat('  ',length(ts),1);
        Scaled.fminF=NaN(length(ts),1);
        Scaled.qdfminF=repmat('  ',length(ts),1);
        Scaled.M3000F1=NaN(length(ts),1);
        Scaled.qdM3000F1=repmat('  ',length(ts),1);
        Scaled.foF3=NaN(length(ts),1);
        Scaled.qdfoF3=repmat('  ',length(ts),1);
        Scaled.hF3=NaN(length(ts),1);
        Scaled.qdhF3=repmat('  ',length(ts),1);
        Scaled.TEC=NaN(length(ts),1);
        %Case M3000 -> M3000F
        Scaled.M3000F=Scaled.M3000;
        Scaled=rmfield(Scaled,'M3000');
        %Order fields
        Scaled=orderfields(Scaled,Vars);   
        hh=datestr(ts,'HH'); mm=datestr(ts,'MM'); ss=datestr(ts,'SS');
end
%Saving in DISS v2 format
DISS_savedata(YY,MM,DD,hh,mm,ss,Scaled,fH,statname,iontype,scalername)

end