#! /bin/bash


pathpol=`more /home/maskedk/Escritorio/DISS/polpath.txt`

polan="/home/maskedk/Escritorio/IPS-42/scaler2/scaler2/polan.exe" 
doc="${pathpol}/polanin.dat"

/usr/lib/wine/wineserver32
/usr/lib/wine/wine $polan $doc
