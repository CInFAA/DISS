function [fbEs,qdfbEs]=fbEscalc(D,i)
    LV={'fminF','ftEs','fmin','foE','fminE','No Value'};
    [s,v]=listdlg('ListString',LV,'SelectionMode','single','ListSize',[200 100],'Name','Numerical Value fbEs');
    if ~v
       return; 
    end
    qd=inputdlg('Enter Q/D letters','fbEs QD Letter');
    if isempty(qd)
       return; 
    end
    if length(qd{1})==2
        qdfbEs=upper(qd{1});
    elseif length(qd{1})==1
        qdfbEs=[' ' upper(qd{1})];
    else
        qdfbEs='  ';
    end
    switch s
        case 1
            fbEs=D.fminF(i);
        case 2
            fbEs=D.ftEs(i);
        case 3
            fbEs=D.fmin(i);
        case 4
            fbEs=D.foE(i);
        case 5
            fbEs=D.fminE(i);
        case 6
            fbEs=NaN;
    end
end