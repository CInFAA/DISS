function [f,h,MF]=pix2data(dataflag,numpix)
switch dataflag
    case 'DIGIPS42'
        f=round(1.0054295.^(0:576),2);
        Equiv_h=[];
        for j=0:7
            aux=linspace(0,100,57);
            Equiv_h=[Equiv_h aux(1:(end-1))+100.*j];
        end
        h=fliplr(round(Equiv_h,2));
        VH_mf=[200 250 300 350 400:100:700];
        for z=1:length(VH_mf)
            MF.cursorvh(z)=find(h==VH_mf(z));
        end
        MF.value=fliplr(f);
        
        mf1=find(MF.value==4.55,1); mf2=find(MF.value==4.04,1);
        mf3=find(MF.value==3.65,1); mf4=find(MF.value==3.33,1);
        mf5=find(MF.value==3.08,1); mf6=find(MF.value==2.69,1);
        mf7=find(MF.value==2.4,1); mf8=find(MF.value==2.2,1);
        MF.cursorf=[mf1,mf2,mf3,mf4,mf5,mf6,mf7,mf8];
    case 'IPS42'
        n_pix=fix(640/9); %X Separation between ticks
        n_height=480/8; %Y Separation between ticks
        
                
        skipf=[];
        for i=1:9
            skp=fix(linspace(1+(64*(i-1)),64*i,n_pix));
            skipf=[skipf,skp]; %#ok<*AGROW>
        end
        
        skiph=[];
        for i=1:8
            skph=fix(linspace(1+(56*(i-1)),56*i,n_height));
            skiph=[skiph,skph];
        end
        
        intvf=round(1.0054295.^(0:577),2); %Extracted from DIGION. Pixel2Frequency
        f=intvf;
        
        VH=[];
        for j=0:7
            aux=linspace(0,100,57);
            VH=[VH aux(1:(end-1))+100.*j];
        end
        h=fliplr(round(VH,2)); %Pixel2VirtualHeight
        
        VH_mf=[200 250 300 350 400:100:700];
        for z=1:length(VH_mf)
            MF.cursorvh(z)=find(h(skiph)==VH_mf(z),1);
        end
        
        MF.value=fliplr(intvf(skipf));
        
        mf1=find(MF.value==4.55,1); mf2=find(MF.value==4.04,1);
        mf3=find(MF.value==3.65,1); mf4=find(MF.value==3.33,1);
        mf5=find(MF.value==3.08,1); mf6=find(MF.value==2.69,1);
        mf7=find(MF.value==2.4,1); mf8=find(MF.value==2.2,1);
        MF.cursorf=[mf1,mf2,mf3,mf4,mf5,mf6,mf7,mf8];
        
        h=h(skiph);
        f=f(skipf);
    case 'analogic'
        n_pixf=numpix.f-mod(numpix.f,9);
        n_pixh=numpix.h-mod(numpix.h,8);
        f=round(2.^(log2(22.5).*((0:n_pixf)./n_pixf)),2);
        VH=[];
        for j=0:7
            aux=linspace(0,100,n_pixh/8);
            VH=[VH aux(1:(end-1))+100.*j];
        end
        h=fliplr(round(VH,2));
        
        VH_mf=[200 250 300 350 400:100:700];
        for z=1:length(VH_mf)
            MF.cursorvh(z)=fndnrst1D(h,VH_mf(z));
        end
        
        MF.value=fliplr(f);
        
        mf1=find(MF.value==4.55,1); mf2=find(MF.value==4.04,1);
        mf3=find(MF.value==3.65,1); mf4=find(MF.value==3.33,1);
        mf5=find(MF.value==3.08,1); mf6=find(MF.value==2.69,1);
        mf7=find(MF.value==2.4,1); mf8=find(MF.value==2.2,1);
        MF.cursorf=[mf1,mf2,mf3,mf4,mf5,mf6,mf7,mf8];
    case 'LISN_OX'
        auxH=round(linspace(100,200,67),1);
        auxH=auxH(1:end-1);
        h=[];
        for i1=0:6
            h=[h auxH+100*i1];
        end
        
        h=[auxH((66-34):end)-100 h];
        h=fliplr(h);
        
        f=[];
        auxF=linspace(2,4,108);
        auxF=auxF(2:end);
        
        for i1=0:5
            f=[f auxF+2*i1];
        end
        
        f=[auxF(85:end)-2 f auxF(1:54)+12];
        
        MF.value=fliplr(round(f,2));
        VH_mf=[200 250 300 350 400:100:700];
        for z=1:length(VH_mf)
            MF.cursorvh(z)=find(h==VH_mf(z));
        end
        
        mf1=fndnrst1D(MF.value,4.55); mf2=fndnrst1D(MF.value,4.04);
        mf3=fndnrst1D(MF.value,3.65); mf4=fndnrst1D(MF.value,3.33);
        mf5=fndnrst1D(MF.value,3.08); mf6=fndnrst1D(MF.value,2.69);
        mf7=fndnrst1D(MF.value,2.4); mf8=fndnrst1D(MF.value,2.2);
        MF.cursorf=[mf1,mf2,mf3,mf4,mf5,mf6,mf7,mf8];
        
        f=round(f,2);
        MF.value=round(MF.value,2);
end
end