function [N_top,indx]=DISSTopside(F,H,name,statname)
Date=name(1:8);
doy=day(datetime(Date,'InputFormat','yyyyMMdd'),'dayofyear');
hh=str2num(name(10:11))-4;
if hh<0
   hh=hh+24;
   doy=doy-1;
end
[val,indx]=max(F);
load(['/home/maskedk/Escritorio/DISSdev/CodeS1/' statname '/Hm_ProduecedBy_2PCAFourierHm_Model.mat'])
H_t=HmModel_Interp(doy,hh+1);
hmF2=H(indx);
h=hmF2:10:1000;
z=(h-hmF2)./H_t; 
N_top=val.*exp((1/2).*(1-z-exp(-z)));
end