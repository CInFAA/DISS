close all; clear all; clc;


version_DISS='2.0.0';
global gui DISSc
gui.tpath=importdata('DISSpath.txt');
DISSc.Elayer=0;
DISSc.Flayer=0; 
DISSc.Eslayer=0;
DISSc.fH=0.62;
DISSc.ionogram=1;
gui.M3000Control=false;
gui.isclosing=true;
gui.heightmode=false;
gui.nonumheight=false;
gui.dir=[]; 
gui.fstart=figure('Menubar','none','Name',['DISS v. ' version_DISS],...
    'NumberTitle','off','Position',[470 220 440 280],'Resize','off');
annotation('textbox',[0.02 0.85 .9 .1],'String',...
    {'Welcome to Digitized Ionogram Scaling Software!','(MATLAB Version)'},...
    'EdgeColor','none','FontWeight','bold')
annotation('textbox',[0.02 0.65 .3 .1],'String',...
    'Ionogram Type:',...
    'EdgeColor','none')
gui.popup1=uicontrol('Style','popup','String',...
    {'DIGION','Camera IPS-42','Analogic Ionogram','LISN OX Image'},'Units','normalized',...
    'Position',[0.035 0.57 0.3 0.1],'Callback',@iontype);

annotation('textbox',[0.02 0.5 .3 .1],'String',...
    'Directory:',...
    'EdgeColor','none')
gui.txbox1=uicontrol('Style','edit','String',...
    {gui.dir},'Units','normalized',...
    'Position',[0.035 0.45 0.6 0.08],'Callback',@dirgui);

gui.btn1=uicontrol('Style','pushbutton','String',...
    {'Browse...'},'Units','normalized',...
    'Position',[0.65 0.45 0.2 0.08],'Callback',@dir_select);

gui.btnend=uicontrol('Style','pushbutton','String',...
    {'Start'},'Units','normalized',...
    'Position',[0.4 0.05 0.2 0.08],'Callback',@endgui);
gui.btnend.Enable='off';
uiwait(gui.fstart)
%If it's closed without pressing "start" button, finish the labour
if gui.isclosing
    return;
end

%%Generating pixel-data relationship
if strcmp(gui.ionclass,'analogic') %Work in progress ()
    [DISSc.F,DISSc.H,DISSc.MF]=pix2data(gui.ionclass,gui.numpix); % Analogic Ionogram needs dimensions
    DISSc.scale='exp';
    ax_f=round(numpix.f/9).*(0:9);
    ax_h=[round(numpix.h/8).*(8:-1:1) 1];
    gui.Flayer.c1=98;
    gui.Flayer.c2=286;
    gui.Flayer.c3=214;
elseif strcmp(gui.ionclass,'LISN_OX')
    [DISSc.F,DISSc.H,DISSc.MF]=pix2data(gui.ionclass);
    DISSc.scale='linear';
    ax_f=[23:107:719 719];
    ax_h=[1 66:66:462];
    %E Layer
    gui.Elayer.c1=5;
    gui.Elayer.c2=60;
    gui.Elayer.c3=65;
    gui.Elayer.cs1=15;
    gui.Elayer.cs2=30;
    %F Layer
    gui.Flayer.c1=10;
    gui.Flayer.c2=66;
    gui.Flayer.c3=132;
    gui.Flayer.cM1=-130;
    gui.Flayer.cM2=-150;
    
else
    [DISSc.F,DISSc.H,DISSc.MF]=pix2data(gui.ionclass);
    DISSc.scale='exp';
    if strcmp(gui.ionclass,'DIGIPS42')
        ax_f=64.*(0:9);

        ax_h=[56.*(8:-1:1) 1];
        %E Layer
        gui.Elayer.c1=100;
        gui.Elayer.c2=190;
        gui.Elayer.c3=256;
        gui.Elayer.cs1=64;
        gui.Elayer.cs2=96;
        %F Layer
        gui.Flayer.c1=98;
        gui.Flayer.c2=286;
        gui.Flayer.c3=280;
        gui.Flayer.cM1=0;
        gui.Flayer.cM2=-20;
    else
        ax_f=71.*(0:9);
        ax_h=[60.*(8:-1:1) 1];
        %E Layer
        gui.Elayer.c1=100;
        gui.Elayer.c2=190;
        gui.Elayer.c3=256;
        gui.Elayer.cs1=71;
        gui.Elayer.cs2=106;
        %F layer
        gui.Flayer.c1=98;
        gui.Flayer.c2=286;
        gui.Flayer.c3=280;
        gui.Flayer.cM1=0;
        gui.Flayer.cM2=-20;
    end
end

answ = inputdlg({'Enter Station name:'},...
    ['DISS v. ' version_DISS]);
if isempty(answ) || isempty(answ{1})
    uiwait(warndlg('Station name will be AAAA'))
    DISSc.statname='AAAA';
else
    DISSc.statname=answ{1};
end

%% Graphic part (Constructing the GUI of scaling)
DISSc.List=dir(gui.path);
DISSc.ionlength=length(DISSc.List)-2;

I=imread([gui.path DISSc.List(DISSc.ionogram+2).name]);

gui.figscale=figure('Menubar','none','Units','normalized','outerposition',[0 0 1 1],...
    'KeyPressFcn',@DISScommands,'Name',['DISS v. ' version_DISS],'NumberTitle','off',...
    'CloseRequestFcn',@closeDISS);
pause(0.01);
frame_h = get(handle(gcf),'JavaFrame');
set(frame_h,'Maximized',1);
if ~strcmp(gui.ionclass,'LISN_OX')
    gui.scal=imagesc(I); colormap(flipud(jet));
    hold on
    ax=gca; ax.Units='normalized';
    ax.Position=[0.18 0.075 0.76 0.85];
    ax.XTick=ax_f+1;
    ax.XTickLabels={'1','1.41','2','2.83','4','5.66','8','11.31','16','f [MHz]'};
    ax.YTick=fliplr(ax_h);
    ax.YTickLabels=fliplr({'0','100','200','300','400','500','600','700','h'' [km]'});
    grid on
    ax.GridColor=[0.85 0.85 0.85]; ax.GridLineStyle=':';
    ax.GridAlpha=0.35;
    ax.FontName='Arial'; ax.FontWeight='bold';
    ax.FontSize=12;
    gui.y_lim=ylim; gui.y_lim(1)=gui.y_lim(1)-1; gui.y_lim(2)=gui.y_lim(2)+1;
    gui.ax=ax;
    name_i=DISSc.List(DISSc.ionogram+2).name;
    YY=name_i(1:4); MM=name_i(5:6); DD=name_i(7:8);
    hh=name_i(10:11); mm=name_i(12:13); ss=name_i(14:15);
    if isempty(str2num(ss))
        ss='00';
    end
    gui.iontitle=title(sprintf('%s-%s-%s %s:%s:%s',YY,MM,DD,hh,mm,ss),...
        'Units','normalized');
else
    gui.scal=imagesc(I); hold on
    ax=gca; ax.Units='normalized';
    ax.Position=[0.18 0.075 0.76 0.85];
    ax.XTick=ax_f;
    ax.YTick=ax_h;
    ax.YTickLabels={'h'' [km]','700','600','500','400','300','200','100'};
    ax.XTickLabels={'2','4','6','8','10','12','14','f [MHz]'};
    grid on
    ax.GridColor=[1 1 1]; ax.GridLineStyle=':';
    ax.GridAlpha=0.35;
    ax.FontName='Arial'; ax.FontWeight='bold';
    ax.FontSize=12;
    gui.y_lim=ylim; gui.y_lim(1)=gui.y_lim(1)-1; gui.y_lim(2)=gui.y_lim(2)+1;
    gui.ax=ax;
    name_i=DISSc.List(DISSc.ionogram+2).name;
    YY=name_i(1:4); MM=name_i(5:6); DD=name_i(7:8);
    hh=name_i(10:11); mm=name_i(12:13); ss=name_i(14:15);
    if isempty(str2num(ss))
        ss='00';
    end
    gui.iontitle=title(sprintf('%s-%s-%s %s:%s:%s',YY,MM,DD,hh,mm,ss),...
        'Units','normalized');
end
%Cursor indicators
gui.vartxt=text(0,1.025,'','Units','normalized',...
    'FontWeight','bold','FontSize',12);
gui.varval=text(0.09,1.025,'','Units','normalized',...
    'FontWeight','bold','FontSize',12);
%Buttons to change ionogram
gui.btn3=uicontrol('Style','pushbutton','String',...
    {' > '},'Units','normalized',...
    'Position',[0.95 0.07 0.04 0.05],'Callback',@ion_forward);
gui.btn4=uicontrol('Style','pushbutton','String',...
    {' < '},'Units','normalized',...
    'Position',[0.95 0.12 0.04 0.05],'Callback',@ion_backward);
DISSc.X=NaN(1,size(I,2)); DISSc.Y=DISSc.X;


%% Creating Dataframe (Table)


VarStruct={'VariablesMain','VariablesEslayer','VariablesElayer',...
    'VariablesFlayer','VariablesFlayerb','VariablesProf'};
DISSc.VariablesMain={'fmin','fxI'};
DISSc.VariablesEslayer={'fminEs','ftEs','fbEs','hEs','TypeEs'};
DISSc.VariablesElayer={'fminE','foE','hE','foE2','hE2'};
DISSc.VariablesFlayer={'fminF','foF1','hF','M3000F1','foF','hF2','M3000F'};
DISSc.VariablesFlayerb={'foF3','hF3'};
DISSc.VariablesProf={'hmF2','TEC'}; %Maybe some more
s=filesep;
if exist([pwd s 'Internaldata' s YY s MM s DISSc.statname YY MM DD '.mat'],'file')==2
    load([pwd s 'Internaldata' s YY s MM s DISSc.statname YY MM DD '.mat'])
    DISSc.Scaled=Scaled;
    clear Scaled
else
    for i_d=VarStruct
        for i_d2=DISSc.(i_d{1})
            if strcmp(i_d2{1},'TypeEs')
                DISSc.Scaled.(i_d2{1})=repmat('     ',DISSc.ionlength,1);
            elseif strcmp(i_d2{1},'ftEs')
                DISSc.Scaled.(i_d2{1})=NaN(DISSc.ionlength,1);
            else
                DISSc.Scaled.(i_d2{1})=NaN(DISSc.ionlength,1);
                if ~strcmp(i_d2{1},'TEC') && ~strcmp(i_d2{1},'hmF2')
                    DISSc.Scaled.(['qd' i_d2{1}])=repmat('  ',DISSc.ionlength,1);
                end
            end
        end
    end
end
for iont=1:DISSc.ionlength
    name_ionogram=DISSc.List(iont+2).name;
    DISSc.hh(iont,:)=name_ionogram(10:11); 
    DISSc.mm(iont,:)=name_ionogram(12:13);
    if ~isempty(str2num(name_ionogram(14:15)))
        DISSc.ss(iont,:)=name_ionogram(14:15);
    else
        DISSc.ss(iont,:)='00';
    end
end

gui.VarCursors={'fminE','foE','foE2',...
    'fminF','foF1','M3000F1','foF','M3000F',...
    'fminEs','ftEs'};
for i_V=1:length(gui.VarCursors)
    eval(['gui.status(' num2str(i_V) ')=0;'])
end
% Display info

DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram);

%% Callback Functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% %% %% %% %% %% %% %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%gui beginning
function dir_select(~,~)
    global gui
    gui.btnend.Enable='off';
    gui.dir=uigetdir('','Select data folder');
    if gui.dir==0
        errordlg('Please select a valid folder!','Error')
        return;
    end
    try
        delete(gui.an_yr)
    catch
    end
    gui.txbox1.String=gui.dir;
    aux=dir(gui.dir);
    gui.yr=[];
    for i=3:length(aux)
        if aux(i).isdir
            gui.yr{i-2}=aux(i).name;
        end
    end
    gui.an_yr=annotation('textbox',[0.03 0.32 .2 .1],'String',...
        'Year:',...
        'EdgeColor','none');
    gui.popup2=uicontrol('Style','popup','String',...
        gui.yr,'Units','normalized',...
        'Position',[0.035 0.25 0.125 0.1],'Callback',@month_select);
end

%Select Month
function month_select(~,~)
    global gui
    if iscell(gui.yr)
        yr=gui.yr{gui.popup2.Value};
    else
        yr=gui.yr;
    end
    aux=[gui.dir filesep yr];
    aux2=dir(aux);
    gui.mth=[];
    for i=3:length(aux2)
        if aux2(i).isdir
            gui.mth{i-2}=aux2(i).name;
        end
    end
    try
        delete(gui.an_mth)
    catch
    end
    gui.an_mth=annotation('textbox',[0.17 0.32 .2 .1],'String',...
        'Month:',...
        'EdgeColor','none');
    gui.popup3=uicontrol('Style','popup','String',...
        gui.mth,'Units','normalized',...
        'Position',[0.175 0.25 0.125 0.1],'Callback',@day_select);
end

    %Select Day
function day_select(~,~)
        global gui
        mth=gui.mth{gui.popup3.Value};
        aux=[gui.dir filesep gui.yr{gui.popup2.Value} filesep mth];
        aux2=dir(aux);
        gui.day=[];
        for i=3:length(aux2)
            if aux2(i).isdir
                gui.day{i-2}=aux2(i).name;
            end
        end
        try
            delete(gui.an_day)
        catch
        end
        gui.an_day=annotation('textbox',[0.31 0.32 .2 .1],'String',...
            'Day:',...
            'EdgeColor','none');
        gui.popup4=uicontrol('Style','popup','String',...
            gui.day,'Units','normalized',...
            'Position',[0.315 0.25 0.125 0.1]);
        gui.btnend.Enable='on';
end

%Ion Type
function iontype(~,~)
    global gui
    gui.btnend.Enable='off';
    if gui.popup1.Value==3
        gui.an_it=annotation('textbox',[0.35 0.65 .3 .1],'String',...
            'Dimensions:','EdgeColor','none');
        gui.txbox2=uicontrol('Style','edit','String',...
            '','Units','normalized',...
            'Position',[0.37 0.59 0.125 0.08]);
        gui.txbox3=uicontrol('Style','edit','String',...
            '','Units','normalized',...
            'Position',[0.5 0.59 0.125 0.08]);
    else
        try
            delete(gui.an_it)
            delete(gui.txbox2)
            delete(gui.txbox3)
        catch
        end
    end
    switch gui.popup1.Value
        case 1
            gui.txbox1.String=gui.tpath{1};
        case 2
            gui.txbox1.String=gui.tpath{2};
        case 3
            gui.txbox1.String=gui.tpath{3};
        case 4
            gui.txbox1.String=gui.tpath{4};
    end
end

%GUI Directory
function dirgui(src,~)
    global gui
    gui.btnend.Enable='off';
    try
        gui.dir=src.String{1};
    catch
        gui.dir=src.String;
    end
    try
        delete(gui.an_yr)
    catch
    end
    gui.txbox1.String=gui.dir;
    aux=dir(gui.dir);
    gui.yr=[];
    for i=3:length(aux)
        if aux(i).isdir
            gui.yr{i-2}=aux(i).name;
        end
    end
    gui.an_yr=annotation('textbox',[0.03 0.32 .2 .1],'String',...
        'Year:',...
        'EdgeColor','none');
    gui.popup2=uicontrol('Style','popup','String',...
        gui.yr,'Units','normalized',...
        'Position',[0.035 0.25 0.125 0.1],'Callback',@month_select);
end

%gui end
function endgui(~,~)
    global gui
    a1=gui.popup2.Value;
    a2=gui.popup3.Value;
    a3=gui.popup4.Value;
    switch gui.popup1.Value
        case 1
            gui.ionclass='DIGIPS42';
        case 2
            gui.ionclass='IPS42';
        case 3
            gui.ionclass='analogic';
            gui.numpix.f=str2num(gui.txbox3.String);
            gui.numpix.h=str2num(gui.txbox2.String);
        case 4
            gui.ionclass='LISN_OX';
    end
    gui.isclosing=false;
    gui.yy=gui.yr{a1};
    gui.mm=gui.mth{a2};
    gui.dd=gui.day{a3};

    gui.path=[gui.dir filesep gui.yy filesep gui.mm filesep gui.dd filesep];

    close(gui.fstart)
end

%% Key Press Function DISS
function DISScommands(~,ev)
    global gui DISSc
    switch ev.Key
        case 'delete'
            if gui.heightmode
                gui.QDgui=figure('Menubar','none','Units','normalized','outerposition',[0.35 0.45 0.25 0.125],...
                    'Name','Saving data (Not Numerical)','NumberTitle','off','WindowStyle','modal','Resize','off');
                gui.QDtext=annotation('textbox',[.025 .8 .9 .1],'String','Enter Qualifying/Descriptive Letters',...
                    'EdgeColor','none','FontSize',10,'FontName','Arial','FontWeight','bold');
                gui.QDtxbox=uicontrol('Style','edit','String','','Units','normalized',...
                    'Position',[0.05 0.15 0.2 0.4],'Callback',@qdfinishH2,'HorizontalAlignment','left');
                uicontrol(gui.QDtxbox);
                uiwait(gui.QDgui);
                uiresume(gui.figscale);
            else
                if strcmp(gui.vartxt.String,'ftEs')
                    DISSc.Scaled.ftEs(DISSc.ionogram)=NaN;
                    I_b=DISSc.ionogram;
                    [DISSc.Scaled.fbEs(I_b),DISSc.Scaled.qdfbEs(I_b,:)]=fbEscalc(DISSc.Scaled,I_b);
                    DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
                    return;
                end
                gui.QDgui=figure('Menubar','none','Units','normalized','outerposition',[0.35 0.45 0.25 0.125],...
                    'Name','Saving data (Not numerical)','NumberTitle','off','WindowStyle','modal','Resize','off');
                gui.QDtext=annotation('textbox',[.025 .8 .9 .1],'String','Enter Qualifying/Descriptive Letters',...
                    'EdgeColor','none','FontSize',10,'FontName','Arial','FontWeight','bold');
                gui.QDtxbox=uicontrol('Style','edit','String','','Units','normalized',...
                    'Position',[0.05 0.15 0.2 0.4],'Callback',@qdfinish2,'HorizontalAlignment','left');
                uicontrol(gui.QDtxbox);
            end
        case 'e'
            switch DISSc.Elayer
                case 0
                    %% Cursor E min
                    gui.cfminE=plot(gui.Elayer.c1.*[1 1],gui.y_lim,':','color',[0 1 0],'LineWidth',2);
                    aux=xlim;
                    lim_a=aux(1)+0.5;
                    lim_b=aux(2)-0.5;
                    draggable(gui.cfminE,'constraint','h',[lim_a lim_b],@cursorfminE);
                    gui.vartxt.String='fminE';
                    gui.varval.String=num2str(DISSc.F(gui.Elayer.c1));
                    gui.status(1)=1;
                    %% Cursor foE
                    gui.cfoE=plot(gui.Elayer.c2.*[1 1],gui.y_lim,'color',[0 1 0],'LineWidth',1.5);
                    indxfB=fndnrst1D(DISSc.F,DISSc.F(round(gui.Elayer.c2))+(1.1*DISSc.fH)/2);
                    gui.cfoE_B=plot(indxfB.*[1 1],gui.y_lim,'--','Color',[0 1 0]);
                    aux=xlim;
                    lim_a=aux(1)+0.5;
                    lim_b=aux(2)-0.5;
                    draggable(gui.cfoE,'constraint','h',[lim_a lim_b],@cursorfoE);
                    gui.status(2)=1;
                    % F to F1 - F2
                    DISSc.Elayer=1;
                case 1
                    %% Cursor foE2
                    gui.cfoE2=plot(gui.Elayer.c3.*[1 1],gui.y_lim,'color',[0 .5 0],'LineWidth',1.5);
                    indxfB=fndnrst1D(DISSc.F,DISSc.F(round(gui.Elayer.c3))+(1.1*DISSc.fH)/2);
                    gui.cfoE2_B=plot(indxfB.*[1 1],gui.y_lim,'--','Color',[0 .5 0]);
                    aux=xlim;
                    lim_a=aux(1)+0.5;
                    lim_b=aux(2)-0.5;
                    draggable(gui.cfoE2,'constraint','h',[lim_a lim_b],@cursorfoE2);
                    gui.status(3)=1;
                    %E1 - E2 to off
                    DISSc.Elayer=2;
                case 2
                    gui.varval.String='';
                    gui.vartxt.String='';
                    %Deleting E
                    x_a=gui.cfminE.XData;
                    x_b=gui.cfoE.XData;
                    gui.Elayer.c1=round(x_a(1,1));
                    gui.Elayer.c2=round(x_b(1,1));
                    delete(gui.cfminE); delete(gui.cfoE);
                    delete(gui.cfoE_B);
                    gui.status(1)=0;
                    gui.status(2)=0;
                    gui.status(3)=0;
                    %Deleting E2
                    x_b=gui.cfoE2.XData;
                    gui.Elayer.c3=round(x_b(1,1));
                    delete(gui.cfoE2); delete(gui.cfoE2_B);
                    %Set to F the next time it's pressed the command
                    DISSc.Elayer=0;
            end
        case 'f'
            switch DISSc.Flayer
                case 0
                    %% Cursor F min
                    gui.cfminF=plot(gui.Flayer.c1.*[1 1],gui.y_lim,':','color',[0.75 0 0],'LineWidth',2);
                    aux=xlim;
                    lim_a=aux(1)+0.5;
                    lim_b=aux(2)-0.5;
                    draggable(gui.cfminF,'constraint','h',[lim_a lim_b],@cursorfminF);
                    gui.vartxt.String='fminF';
                    gui.varval.String=num2str(DISSc.F(gui.Flayer.c1));
                    gui.status(4)=1;
                    %% Cursor foF
                    gui.cfoF=plot(gui.Flayer.c2.*[1 1],gui.y_lim,'color',[0.75 0 0],'LineWidth',1.5);
                    indxfB=fndnrst1D(DISSc.F,DISSc.F(round(gui.Flayer.c2))+DISSc.fH/2);
                    gui.cfoF_B=plot(indxfB.*[1 1],gui.y_lim,'--','Color',[0.75 0 0]);
                    aux=xlim;
                    lim_a=aux(1)+0.5;
                    lim_b=aux(2)-0.5;
                    draggable(gui.cfoF,'constraint','h',[lim_a lim_b],@cursorfoF);
                    gui.status(7)=1;
                    % F to F1 - F2
                    DISSc.Flayer=1;
                case 1
                    %% Cursor foF1
                    gui.cfoF1=plot(gui.Flayer.c3.*[1 1],gui.y_lim,'Color',[1 0.5 0.5],'LineWidth',1.5);
                    indxfB=fndnrst1D(DISSc.F,DISSc.F(round(gui.Flayer.c3))+DISSc.fH/2);
                    gui.cfoF1_B=plot(indxfB.*[1 1],gui.y_lim,'--','Color',[1 0.5 0.5]);
                    aux=xlim;
                    lim_a=aux(1)+0.5;
                    lim_b=aux(2)-0.5;
                    draggable(gui.cfoF1,'constraint','h',[lim_a lim_b],@cursorfoF1);
                    gui.status(5)=1;
                    % M3000F1 (if it's activated)
                    if gui.M3000Control
                        M_f=DISSc.MF.cursorf;
                        M_h=DISSc.MF.cursorvh;
                        gui.cM3000F1=plot(M_f+gui.Flayer.cM2,M_h,'Color',[0.5 0 1],'LineWidth',1.5);
                        gui.status(6)=1;
                        draggable(gui.cM3000F1,'constraint','h',@cursorM3000F1);
                    end
                    DISSc.Flayer=2;
                case 2
                    gui.varval.String='';
                    gui.vartxt.String='';
                    %Deleting F1
                    x_a=gui.cfoF1.XData;
                    gui.Flayer.c3=round(x_a(1,1));
                    delete(gui.cfoF1);delete(gui.cfoF1_B);
                    %Deleting F2 - M3000(F1) - M3000(F/F2)
                    x_a=gui.cfminF.XData;
                    x_b=gui.cfoF.XData;
                    gui.Flayer.c1=round(x_a(1,1));
                    gui.Flayer.c2=round(x_b(1,1));
                    delete(gui.cfminF); delete(gui.cfoF);
                    delete(gui.cfoF_B);
                    gui.status(4)=0;
                    gui.status(5)=0;
                    gui.status(7)=0;
                    if gui.M3000Control
                        try
                            gui.Flayer.cM1=DISSc.despM1;
                            gui.Flayer.cM2=DISSc.despM2;
                        catch
                        end
                        delete(gui.cM3000F1)
                        delete(gui.cM3000F)
                        gui.status(6)=0;
                        gui.status(8)=0;
                        gui.M3000Control=false;
                    end
                    %Set to F the next time it's pressed the command
                    DISSc.Flayer=0;
            end
        %Gyrofrequency
        case 'g'
            gui.QDgui=figure('Menubar','none','Units','normalized','outerposition',[0.45 0.45 0.07 0.125],...
                'Name','fH','NumberTitle','off','WindowStyle','modal','Resize','off');
            gui.QDtext=annotation('textbox',[.025 .8 .9 .1],'String','fH :',...
                'EdgeColor','none','FontSize',10,'FontName','Arial','FontWeight','bold');
            gui.QDtxbox=uicontrol('Style','edit','String',num2str(DISSc.fH,'%4.2f'),'Units','normalized',...
                'Position',[0.09 0.15 0.5 0.4],'Callback',@fhsel,'HorizontalAlignment','left');
            uicontrol(gui.QDtxbox);
        %% Virtual/Real Height mode
        case 'h'
            if ~gui.heightmode
                if gui.M3000Control
                    if DISSc.Flayer==2
                        delete(gui.cM3000F1)
                        delete(gui.cM3000F)
                        gui.status(6)=0;
                        gui.status(8)=0;
                    else
                        delete(gui.cM3000F)
                        gui.status(8)=0;
                    end
                    gui.M3000Control=false;
                end
                gui.heightmode=true;
                I=DISSc.ionogram;
                gui.vartxt.String='';
                gui.varval.String='';
                gui.vartxtheight=text(0,1.025,'V.Height','Units','normalized',...
                    'FontWeight','bold','FontSize',12);
                gui.varlyrheight=text(0.1,1.025,'','Units','normalized',...
                    'FontWeight','bold','FontSize',12);
                if DISSc.Elayer~=0
                    draggable(gui.cfminE,'off')
                    draggable(gui.cfoE,'off')
                    if DISSc.Elayer==2
                        draggable(gui.cfoE2,'off')
                    end
                end
                if DISSc.Flayer~=0
                    draggable(gui.cfminF,'off')
                    draggable(gui.cfoF,'off')
                    if DISSc.Flayer==2
                        draggable(gui.cfoF1,'off')
                    end
                end
                if DISSc.Eslayer~=0
                    draggable(gui.cfminEs,'off')
                    draggable(gui.cftEs,'off')
                end
                if DISSc.Elayer~=0
                    gui.varlyrheight.String='E layer';
                    l1=round(gui.cfminE.XData(1));
                    l2=round(gui.cfoE.XData(1));
                    drawDISSv2(gcf,DISSc.X,DISSc.Y,l1,l2,[.5 .5 .5])
                    uiwait(gcf)
                    B1=findobj(gca,'Type','Line','Color',[.5 .5 .5]);
                    if ~isempty(B1)
                        gui.h_draw(I).E=[B1.XData' B1.YData'];
                        auxnan=~isnan(gui.h_draw(I).E(:,1));
                        gui.h_draw(I).E=gui.h_draw(I).E(auxnan,:);
                    end
                    if ~gui.nonumheight
                        haux=max(round(gui.h_draw(I).E(:,2)));
                        DISSc.Scaled.hE(I)=DISSc.H(haux);
                        gui.nonumheight=false;
                    end
                    set(gcf,'WindowButtonDownFcn','')
                    set(gcf,'WindowButtonMotionFcn','')
                    set(gcf,'WindowButtonUpFcn','')
                    if DISSc.Elayer==2
                        gui.varlyrheight.String='E2 layer';
                        l1=round(gui.cfoE.XData(1));
                        l2=round(gui.cfoE2.XData(1));
                        drawDISSv2(gcf,DISSc.X,DISSc.Y,l1,l2,[.35 .35 .35])
                        uiwait(gcf)
                        B2=findobj(gca,'Type','Line','Color',[.35 .35 .35]);
                        if ~isempty(B2)
                            gui.h_draw(I).E2=[B2.XData' B2.YData'];
                            auxnan=~isnan(gui.h_draw(I).E2(:,1));
                            gui.h_draw(I).E2=gui.h_draw(I).E2(auxnan,:);
                        end
                        if ~gui.nonumheight
                            haux=max(round(gui.h_draw(I).E2(:,2)));
                            DISSc.Scaled.hE2(I)=DISSc.H(haux);
                            gui.nonumheight=false;
                        end
                        set(gcf,'WindowButtonDownFcn','')
                        set(gcf,'WindowButtonMotionFcn','')
                        set(gcf,'WindowButtonUpFcn','')
                        x_b=gui.cfoE2.XData;
                        gui.Elayer.c3=round(x_b(1,1));
                        delete(gui.cfoE2)
                        delete(gui.cfoE2_B)
                        gui.status(3)=0;
                    end
                    x_a=gui.cfminE.XData;
                    x_b=gui.cfoE.XData;
                    gui.Elayer.c1=round(x_a(1,1));
                    gui.Elayer.c2=round(x_b(1,1));
                    gui.status(1)=0;
                    gui.status(2)=0;
                    delete(gui.cfminE)
                    delete(gui.cfoE)
                    delete(gui.cfoE_B)
                    DISSc.Elayer=0;
                end
                if DISSc.Flayer~=0
                    if DISSc.Flayer==1
                       l1=round(gui.cfminF.XData(1));
                       l2=round(gui.cfoF.XData(1));
                       gui.varlyrheight.String='F layer';
                    else
                       l1=round(gui.cfminF.XData(1));
                       l2=round(gui.cfoF1.XData(1));
                       gui.varlyrheight.String='F1 layer';
                    end
                    drawDISSv2(gcf,DISSc.X,DISSc.Y,l1,l2,[0 .5 .5])
                    uiwait(gcf)
                    B1=findobj(gca,'Type','Line','Color',[0 .5 .5]);
                    if ~isempty(B1)
                        gui.h_draw(I).F=[B1.XData' B1.YData'];
                        auxnan=~isnan(gui.h_draw(I).F(:,1));
                        gui.h_draw(I).F=gui.h_draw(I).F(auxnan,:);
                    end
                    if ~gui.nonumheight
                        haux=max(round(gui.h_draw(I).F(:,2)));
                        DISSc.Scaled.hF(I)=DISSc.H(haux);
                        gui.nonumheight=false;
                    end
                    set(gcf,'WindowButtonDownFcn','')
                    set(gcf,'WindowButtonMotionFcn','')
                    set(gcf,'WindowButtonUpFcn','')
                    if DISSc.Flayer==2
                        gui.varlyrheight.String='F2 layer';
                        l1=round(gui.cfoF1.XData(1));
                        l2=round(gui.cfoF.XData(1));
                        drawDISSv2(gcf,DISSc.X,DISSc.Y,l1,l2,[0 .35 .35])
                        uiwait(gcf)
                        B2=findobj(gca,'Type','Line','Color',[0 .35 .35]);
                        if ~isempty(B2)
                            gui.h_draw(I).F2=[B2.XData' B2.YData'];
                            auxnan=~isnan(gui.h_draw(I).F2(:,1));
                            gui.h_draw(I).F2=gui.h_draw(I).F2(auxnan,:);
                        end
                        if ~gui.nonumheight
                            haux=max(round(gui.h_draw(I).F2(:,2)));
                            DISSc.Scaled.hF2(I)=DISSc.H(haux);
                            gui.nonumheight=false;
                        end
                        set(gcf,'WindowButtonDownFcn','')
                        set(gcf,'WindowButtonMotionFcn','')
                        set(gcf,'WindowButtonUpFcn','')
                        x_a=gui.cfoF1.XData;
                        gui.Flayer.c3=round(x_a(1,1));
                        delete(gui.cfoF1)
                        delete(gui.cfoF1_B)
                        gui.status(5)=0;
                    end
                    x_a=gui.cfminF.XData;
                    x_b=gui.cfoF.XData;
                    gui.Flayer.c1=round(x_a(1,1));
                    gui.Flayer.c2=round(x_b(1,1));
                    gui.status(4)=0;
                    gui.status(7)=0;
                    delete(gui.cfminF)
                    delete(gui.cfoF)
                    delete(gui.cfoF_B)
                    DISSc.Flayer=0;
                end
                if DISSc.Eslayer~=0
                    gui.varlyrheight.String='Es layer';
                    l1=round(gui.cfminEs.XData(1));
                    l2=round(gui.cftEs.XData(1));
                    drawDISSv2(gcf,DISSc.X,DISSc.Y,l1,l2,[.5 .5 0])
                    uiwait(gcf)
                    B3=findobj(gca,'Type','Line','Color',[.5 .5 0]);
                    if ~isempty(B3)
                        gui.h_draw(I).Es=[B3.XData' B3.YData'];
                    end
                    if ~gui.nonumheight
                        haux=max(round(gui.h_draw(I).Es(:,2)));
                        DISSc.Scaled.hEs(I)=DISSc.H(haux);
                        gui.nonumheight=false;
                    end
                    set(gcf,'WindowButtonDownFcn','')
                    set(gcf,'WindowButtonMotionFcn','')
                    set(gcf,'WindowButtonUpFcn','')
                    gui.Elayer.cs1=gui.cfminEs.XData(1);
                    gui.Elayer.cs2=gui.cftEs.XData(1);
                    delete(gui.cfminEs)
                    delete(gui.cftEs)
                    gui.status(9)=0;
                    gui.status(10)=0;
                    DISSc.Eslayer=0;
                end
                B1=findobj(gca,'Type','Line','Color',[.5 .5 .5]);
                if ~isempty(B1)
                    delete(B1);
                end
                B2=findobj(gca,'Type','Line','Color',[.35 .35 .35]);
                if ~isempty(B2)
                    delete(B2);
                end
                B1=findobj(gca,'Type','Line','Color',[0 .5 .5]);
                if ~isempty(B1)
                    delete(B1);
                end
                B2=findobj(gca,'Type','Line','Color',[0 .35 .35]);
                if ~isempty(B2)
                    delete(B2);
                end
                B3=findobj(gca,'Type','Line','Color',[.5 .5 0]);
                if ~isempty(B3)
                    delete(B3);
                end
                delete(gui.varlyrheight);
                gui.heightmode=false;
                name_i=DISSc.List(DISSc.ionogram+2).name;
                if ~isfield(DISSc,'dip')
                    answ=inputdlg({'Enter dip angle of station','Enter name station'});
                    if ~isempty(answ)
                        DISSc.dip=str2num(answ{1});
                        DISSc.statname=answ{2};
                    else
                        DISSc.dip=[];
                    end
                end
                if ~isempty(DISSc.dip)
                gui.vartxtheight.String='POLAN running. Please wait...';
                pause(0.5)
                [DISSc.POLAN(I).RH,DISSc.POLAN(I).F,...
                    DISSc.Scaled.hmF2(I),DISSc.Scaled.TEC(I)]=...
                    DISS_runpolan(gui.h_draw(I),...
                    DISSc.F,DISSc.H,name_i,DISSc.fH,DISSc.dip,DISSc.statname,DISSc.scale);
                else
                    DISSc=rmfield(DISSc,'dip');
                end
                delete(gui.vartxtheight);
                DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
            end 
        case 'leftarrow'
            if ~isempty(gui.vartxt.String)
                clab=['c' gui.vartxt.String];
                if ~strcmp(clab,'cM3000F')
                    if gui.(clab).XData(1)-1<1
                        gui.(clab).XData(:)=[1 1];
                    else
                        gui.(clab).XData(:)=gui.(clab).XData(:)-1;
                    end
                else
                    gui.(clab).XData(:)=gui.(clab).XData(:)-1;
                end
                
                if strcmp(clab,'cM3000F')
                    DISSc.despM1=round(gui.(clab).XData(1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(round(gui.cfoF.XData(1)-DISSc.despM1));
                elseif strcmp(clab,'cM3000F1')
                    DISSc.despM2=round(gui.(clab).XData(1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(round(gui.cfoF1.XData(1)-DISSc.despM2));
                else
                    auxval=DISSc.F(round(gui.(clab).XData(1)));
                end
                if strcmp(gui.vartxt.String(1:2),'fo')
                    if strcmp(gui.vartxt.String(3),'E')
                        auxvalx=auxval+(1.1*DISSc.fH)/2;
                    else
                        auxvalx=auxval+DISSc.fH/2;
                    end 
                    indxfB=fndnrst1D(DISSc.F,auxvalx);
                    gui.([clab '_B']).XData(:)=indxfB*[1 1];
                end
                gui.varval.String=num2str(auxval);
            end
        %% M3000 cursors
        case 'm'
            switch DISSc.Flayer
                case 1
                    if gui.M3000Control
                        gui.Flayer.cM1=DISSc.despM1;
                        delete(gui.cM3000F)
                        gui.M3000Control=false;
                        gui.status(8)=0;
                        gui.vartxt.String='';
                        gui.varval.String='';
                    else
                        M_f=DISSc.MF.cursorf;
                        M_h=DISSc.MF.cursorvh;
                        gui.cM3000F=plot(M_f+gui.Flayer.cM1,M_h,'m','LineWidth',1.5);
                        draggable(gui.cM3000F,'constraint','h',[-100 length(gui.scal.CData)],@cursorM3000F);
                        gui.status(8)=1;
                        gui.M3000Control=true;
                    end
                case 2
                    if gui.M3000Control
                        try
                            gui.Flayer.cM1=DISSc.despM1;
                        catch
                        end
                        try
                            gui.Flayer.cM2=DISSc.despM2;
                        catch
                        end
                        delete(gui.cM3000F)
                        delete(gui.cM3000F1)
                        gui.M3000Control=false;
                        gui.vartxt.String='';
                        gui.varval.String='';
                        gui.status(6)=0;
                        gui.status(8)=0;
                    else
                        M_f=DISSc.MF.cursorf;
                        M_h=DISSc.MF.cursorvh;
                        gui.cM3000F=plot(M_f+gui.Flayer.cM1,M_h,'Color',[1 0 1],'LineWidth',1.5);
                        gui.cM3000F1=plot(M_f+gui.Flayer.cM2,M_h,'Color',[0.5 0 1],'LineWidth',1.5);
                        draggable(gui.cM3000F,'constraint','h',[-100 length(gui.scal.CData)],@cursorM3000F);
                        draggable(gui.cM3000F1,'constraint','h',@cursorM3000F1);
                        gui.M3000Control=true;
                        gui.status(6)=1;
                        gui.status(8)=1;
                    end
            end
        case 'pagedown'
            DISSc.ionogram=DISSc.ionogram+1;
            if DISSc.ionogram>DISSc.ionlength
                DISSc.ionogram=DISSc.ionlength;
            end
            I=imread([gui.path DISSc.List(DISSc.ionogram+2).name]);
            gui.scal.CData=I;
            name_i=DISSc.List(DISSc.ionogram+2).name;
            YY=name_i(1:4); MM=name_i(5:6); DD=name_i(7:8);
            hh=name_i(10:11); mm=name_i(12:13); ss=name_i(14:15);
            if isempty(str2num(ss))
                ss='00';
            end
            gui.iontitle.String=sprintf('%s-%s-%s %s:%s:%s',YY,MM,DD,hh,mm,ss);
            DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
        case 'pageup'
            DISSc.ionogram=DISSc.ionogram-1;
            if DISSc.ionogram<1
                DISSc.ionogram=1;
            end
            I=imread([gui.path DISSc.List(DISSc.ionogram+2).name]);
            gui.scal.CData=I;
            name_i=DISSc.List(DISSc.ionogram+2).name;
            YY=name_i(1:4); MM=name_i(5:6); DD=name_i(7:8);
            hh=name_i(10:11); mm=name_i(12:13); ss=name_i(14:15);
            if isempty(str2num(ss))
                ss='00';
            end
            gui.iontitle.String=sprintf('%s-%s-%s %s:%s:%s',YY,MM,DD,hh,mm,ss);
            DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
        case 'return'
            if gui.heightmode
                gui.QDgui=figure('Menubar','none','Units','normalized','outerposition',[0.35 0.45 0.25 0.125],...
                    'Name','Saving data','NumberTitle','off','WindowStyle','modal','Resize','off');
                gui.QDtext=annotation('textbox',[.025 .8 .9 .1],'String','Enter Qualifying/Descriptive Letters',...
                    'EdgeColor','none','FontSize',10,'FontName','Arial','FontWeight','bold');
                gui.QDtxbox=uicontrol('Style','edit','String','','Units','normalized',...
                    'Position',[0.05 0.15 0.2 0.4],'Callback',@qdfinishH,'HorizontalAlignment','left');
                uicontrol(gui.QDtxbox);
                uiwait(gui.QDgui);
                uiresume(gui.figscale);
            end
            if ~isempty(gui.vartxt.String)
                if strcmp(gui.vartxt.String,'ftEs')
                    DISSc.Scaled.ftEs(DISSc.ionogram)=DISSc.F(round(gui.cftEs.XData(1)));
                    gui.TEs=figure('Menubar','none','Units','normalized','outerposition',[0.35 0.45 0.25 0.125],...
                    'Name','Type Es','NumberTitle','off','WindowStyle','modal','Resize','off');
                    gui.TEstext=annotation('textbox',[.025 .8 .9 .1],'String','Enter Type Es (Type - N° Echoes)',...
                    'EdgeColor','none','FontSize',10,'FontName','Arial','FontWeight','bold');
                    gui.TEstxbox=uicontrol('Style','edit','String','','Units','normalized',...
                    'Position',[0.05 0.15 0.2 0.4],'Callback',@TEsfcn,'HorizontalAlignment','left');
                    uicontrol(gui.TEstxbox);
                    uiwait(gui.TEs)
                    I_b=DISSc.ionogram;
                    [DISSc.Scaled.fbEs(I_b),DISSc.Scaled.qdfbEs(I_b,:)]=fbEscalc(DISSc.Scaled,I_b);
                    DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
                    return;
                end
                gui.QDgui=figure('Menubar','none','Units','normalized','outerposition',[0.35 0.45 0.25 0.125],...
                    'Name','Saving data','NumberTitle','off','WindowStyle','modal','Resize','off');
                gui.QDtext=annotation('textbox',[.025 .8 .9 .1],'String','Enter Qualifying/Descriptive Letters',...
                    'EdgeColor','none','FontSize',10,'FontName','Arial','FontWeight','bold');
                gui.QDtxbox=uicontrol('Style','edit','String','','Units','normalized',...
                    'Position',[0.05 0.15 0.2 0.4],'Callback',@qdfinish,'HorizontalAlignment','left');
                uicontrol(gui.QDtxbox);
            end
        case 'rightarrow'
            if ~isempty(gui.vartxt.String)
                clab=['c' gui.vartxt.String];
                if gui.(clab).XData(1)+1>length(gui.scal.CData)
                    gui.(clab).XData(:)=length(gui.scal.CData).*[1 1];
                else
                    gui.(clab).XData(:)=gui.(clab).XData(:)+1;
                end
                if strcmp(clab,'cM3000F')
                    DISSc.despM1=round(gui.(clab).XData(1,1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(round(gui.cfoF.XData(1,1)-DISSc.despM1));
                elseif strcmp(clab,'cM3000F1')
                    DISSc.despM2=round(gui.(clab).XData(1,1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(round(gui.cfoF1.XData(1,1)-DISSc.despM2));
                else
                    auxval=DISSc.F(round(gui.(clab).XData(1)));
                end
                if strcmp(gui.vartxt.String(1:2),'fo')
                    if strcmp(gui.vartxt.String(3),'E')
                        auxvalx=auxval+(1.1*DISSc.fH)/2;
                    else
                        auxvalx=auxval+DISSc.fH/2;
                    end
                    indxfB=fndnrst1D(DISSc.F,auxvalx);
                    gui.([clab '_B']).XData(:)=indxfB*[1 1];
                end
                gui.varval.String=num2str(auxval);
            end
        case 's'
            switch DISSc.Eslayer
                case 0
                    ay=ylim;
                    gui.cfminEs=plot(gui.Elayer.cs1*[1 1],[mean(ay) ay(2)],'Color',[0 0.8 0.8],'LineWidth',1.5);
                    aux=xlim;
                    lim_a=aux(1)+0.5;
                    lim_b=aux(2)-0.5;
                    draggable(gui.cfminEs,'constraint','h',[lim_a lim_b],@cursorfminEs);
                    gui.cftEs=plot(gui.Elayer.cs2*[1 1],[mean(ay) ay(2)],'Color','c','LineWidth',1.5);
                    draggable(gui.cftEs,'constraint','h',[lim_a lim_b],@cursorftEs);
                    DISSc.Eslayer=1;
                    gui.status(9)=1;
                    gui.status(10)=1;
                case 1
                    gui.varval.String='';
                    gui.vartxt.String='';
                    gui.Elayer.cs1=gui.cfminEs.XData(1);
                    gui.Elayer.cs2=gui.cftEs.XData(1);
                    delete(gui.cfminEs)
                    delete(gui.cftEs)
                    gui.status(9)=0;
                    gui.status(10)=0;
                    DISSc.Eslayer=0;
            end
        case 'space'
            cursors_on=gui.VarCursors(gui.status==1);
            if isempty(cursors_on)
                return;
            end
            if ~isempty(gui.vartxt.String)
                auxC=strcmp(cursors_on,gui.vartxt.String);
                gui.Cnum=find(auxC==1);
                if gui.Cnum+1>length(cursors_on)
                    gui.Cnum=0;
                end
                gui.vartxt.String=cursors_on{gui.Cnum+1};
                
                if strcmp(cursors_on{gui.Cnum+1},'M3000F')
                    DISSc.despM1=round(gui.(['c' cursors_on{gui.Cnum+1}]).XData(1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(round(gui.cfoF.XData(1,1)-DISSc.despM1));
                    gui.varval.String=num2str(auxval);
                elseif strcmp(cursors_on{gui.Cnum+1},'M3000F1')
                    DISSc.despM2=round(gui.(['c' cursors_on{gui.Cnum+1}]).XData(1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(round(gui.cfoF1.XData(1,1)-DISSc.despM2));
                    gui.varval.String=num2str(auxval);
                else
                    auxval=round(gui.(['c' cursors_on{gui.Cnum+1}]).XData(1));
                    gui.varval.String=num2str(DISSc.F(auxval));
                end
            else
                auxC=zeros(1,length(cursors_on));
                auxC(1)=1;
                gui.Cnum=find(auxC==1);
                gui.vartxt.String=cursors_on{gui.Cnum};
                auxval=round(gui.(['c' cursors_on{gui.Cnum}]).XData(1));
                if strcmp(cursors_on{gui.Cnum},'M3000F')
                    DISSc.despM1=round(gui.(['c' cursors_on{gui.Cnum}]).XData(1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(gui.cfoF.XData(1,1)-DISSc.despM1);
                    gui.varval.String=num2str(auxval);
                elseif strcmp(cursors_on{gui.Cnum},'M3000F1')
                    DISSc.despM2=round(gui.(['c' cursors_on{gui.Cnum}]).XData(1)-DISSc.MF.cursorf(1));
                    auxval=DISSc.MF.value(gui.cfoF1.XData(1,1)-DISSc.despM2);
                    gui.varval.String=num2str(auxval);
                else
                    gui.varval.String=num2str(DISSc.F(auxval));
                end
            end
    end
end
%% GUI to ionogram scaling
function ion_forward(~,~)
global DISSc gui
DISSc.ionogram=DISSc.ionogram+1;
if DISSc.ionogram>DISSc.ionlength
    DISSc.ionogram=DISSc.ionlength;
end
I=imread([gui.path DISSc.List(DISSc.ionogram+2).name]);
gui.scal.CData=I;
name_i=DISSc.List(DISSc.ionogram+2).name;
YY=name_i(1:4); MM=name_i(5:6); DD=name_i(7:8);
hh=name_i(10:11); mm=name_i(12:13); ss=name_i(14:15);
if isempty(str2num(ss))
    ss='00';
end
gui.iontitle.String=sprintf('%s-%s-%s %s:%s:%s',YY,MM,DD,hh,mm,ss);
DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
end

function ion_backward(~,~)
global DISSc gui
DISSc.ionogram=DISSc.ionogram-1;
if DISSc.ionogram<1
    DISSc.ionogram=1;
end
I=imread([gui.path DISSc.List(DISSc.ionogram+2).name]);
gui.scal.CData=I;
name_i=DISSc.List(DISSc.ionogram+2).name;
YY=name_i(1:4); MM=name_i(5:6); DD=name_i(7:8);
hh=name_i(10:11); mm=name_i(12:13); ss=name_i(14:15);
if isempty(str2num(ss))
    ss='00';
end
gui.iontitle.String=sprintf('%s-%s-%s %s:%s:%s',YY,MM,DD,hh,mm,ss);
DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
end



%% Cursors Callback
%E layer
function cursorfminE(h)
global gui DISSc
gui.vartxt.String='fminE';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
end

function cursorfoE(h)
global gui DISSc
gui.vartxt.String='foE';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
indxfB=fndnrst1D(DISSc.F,DISSc.F(round(h.XData(1)))+(1.1*DISSc.fH)/2);
gui.cfoE_B.XData=indxfB.*[1 1]; gui.cfoE_B.YData=gui.y_lim;
end

function cursorfoE2(h)
global gui DISSc
gui.vartxt.String='foE2';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
indxfB=fndnrst1D(DISSc.F,DISSc.F(round(h.XData(1)))+(1.1*DISSc.fH)/2);
gui.cfoE2_B.XData=indxfB.*[1 1]; gui.cfoE_B.YData=gui.y_lim;
end
%F layer
function cursorfminF(h)
global gui DISSc
gui.vartxt.String='fminF';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
end

function cursorfoF(h)
global gui DISSc
gui.vartxt.String='foF';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
indxfB=fndnrst1D(DISSc.F,DISSc.F(round(h.XData(1)))+DISSc.fH/2);
gui.cfoF_B.XData=indxfB.*[1 1]; gui.cfoF_B.YData=gui.y_lim;
end
% F1
function cursorfoF1(h)
global gui DISSc
gui.vartxt.String='foF1';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
indxfB=fndnrst1D(DISSc.F,DISSc.F(round(h.XData(1)))+DISSc.fH/2);
gui.cfoF1_B.XData=indxfB.*[1 1]; gui.cfoF1_B.YData=gui.y_lim;
end

%M3000F/F2
function cursorM3000F(h)
global gui DISSc
DISSc.despM1=round(h.XData(1)-DISSc.MF.cursorf(1));
posfoF=gui.cfoF.XData(1);
gui.vartxt.String='M3000F';
gui.varval.String=num2str(DISSc.MF.value(round(posfoF(1,1))-DISSc.despM1));
end

%M3000F1
function cursorM3000F1(h)
global gui DISSc
DISSc.despM2=round(h.XData(1)-DISSc.MF.cursorf(1));
posfoF1=gui.cfoF1.XData(1);
gui.vartxt.String='M3000F1';
gui.varval.String=num2str(DISSc.MF.value(round(posfoF1(1,1))-DISSc.despM2));
end

%E-sporadic
%fminEs
function cursorfminEs(h)
global gui DISSc
gui.vartxt.String='fminEs';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
end

%ftEs
function cursorftEs(h)
global gui DISSc
gui.vartxt.String='ftEs';
gui.varval.String=num2str(DISSc.F(round(h.XData(1))));
end

%QD Letters
function qdfinish(src,~)
global gui DISSc
I=DISSc.ionogram;
Var=gui.vartxt.String;
switch Var
    case 'fminE'
        if size(src.String,2)==1
            DISSc.Scaled.qdfminE(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfminE(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfminE(I,:)='  ';
        end
        DISSc.Scaled.fminE(I)=DISSc.F(round(gui.cfminE.XData(1)));
        [DISSc.Scaled.fmin(I),DISSc.Scaled.qdfmin(I,:)]=fmincalc(DISSc.Scaled,I);
    case 'foE'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoE(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoE(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoE(I,:)='  ';
        end
        DISSc.Scaled.foE(I)=DISSc.F(round(gui.cfoE.XData(1)));
    case 'foE2'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoE2(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoE2(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoE2(I,:)='  ';
        end
        DISSc.Scaled.foE2(I)=DISSc.F(round(gui.cfoE2.XData(1)));
    case 'fminF'
        if size(src.String,2)==1
            DISSc.Scaled.qdfminF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfminF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfminF(I,:)='  ';
        end
        DISSc.Scaled.fminF(I)=DISSc.F(round(gui.cfminF.XData(1)));
        [DISSc.Scaled.fmin(I),DISSc.Scaled.qdfmin(I,:)]=fmincalc(DISSc.Scaled,I);
    case 'foF'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoF(I,:)='  ';
        end
        DISSc.Scaled.foF(I)=DISSc.F(round(gui.cfoF.XData(1)));
    case 'foF1'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoF1(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoF1(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoF1(I,:)='  ';
        end
        DISSc.Scaled.foF1(I)=DISSc.F(round(gui.cfoF1.XData(1)));
    case 'M3000F'
        if size(src.String,2)==1
            DISSc.Scaled.qdM3000F(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdM3000F(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdM3000F(I,:)='  ';
        end
        DISSc.Scaled.M3000F(I)=DISSc.MF.value(round(gui.cfoF.XData(1,1))-DISSc.despM1);
    case 'M3000F1'
        if size(src.String,2)==1
            DISSc.Scaled.qdM3000F1(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdM3000F1(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdM3000F1(I,:)='  ';
        end
        DISSc.Scaled.M3000F1(I)=DISSc.MF.value(round(gui.cfoF1.XData(1,1))-DISSc.despM2);
    case 'fminEs'
        if size(src.String,2)==1
            DISSc.Scaled.qdfminEs(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfminEs(I,:)=upper(src.String);
        end
        DISSc.Scaled.fminEs(I)=DISSc.F(round(gui.cfminEs.XData(1)));
        [DISSc.Scaled.fmin(I),DISSc.Scaled.qdfmin(I,:)]=fmincalc(DISSc.Scaled,I);
end
close(gcbf);
DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
end

function qdfinish2(src,~)
global gui DISSc
I=DISSc.ionogram;
Var=gui.vartxt.String;
switch Var
    case 'fminE'
        if size(src.String,2)==1
            DISSc.Scaled.qdfminE(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfminE(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfminE(I,:)='  ';
        end
        DISSc.Scaled.fminE(I)=NaN;
        [DISSc.Scaled.fmin(I),DISSc.Scaled.qdfmin(I,:)]=fmincalc(DISSc.Scaled,I);
    case 'foE'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoE(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoE(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoE(I,:)='  ';
        end
        DISSc.Scaled.foE(I)=NaN;
    case 'foE2'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoE2(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoE2(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoE2(I,:)='  ';
        end
        DISSc.Scaled.foE2(I)=NaN;
    case 'fminF'
        if size(src.String,2)==1
            DISSc.Scaled.qdfminF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfminF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfminF(I,:)='  ';
        end
        DISSc.Scaled.fminF(I)=NaN;
        [DISSc.Scaled.fmin(I),DISSc.Scaled.qdfmin(I,:)]=fmincalc(DISSc.Scaled,I);
    case 'foF'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoF(I,:)='  ';
        end
        DISSc.Scaled.foF(I)=NaN;
    case 'foF1'
        if size(src.String,2)==1
            DISSc.Scaled.qdfoF1(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfoF1(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfoF1(I,:)='  ';
        end
        DISSc.Scaled.foF1(I)=NaN;
    case 'M3000F'
        if size(src.String,2)==1
            DISSc.Scaled.qdM3000F(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdM3000F(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdM3000F(I,:)='  ';
        end
        DISSc.Scaled.M3000F(I)=NaN;
    case 'M3000F1'
        if size(src.String,2)==1
            DISSc.Scaled.qdM3000F1(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdM3000F1(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdM3000F1(I,:)='  ';            
        end
        DISSc.Scaled.M3000F1(I)=NaN;
    case 'fminEs'
        if size(src.String,2)==1
            DISSc.Scaled.qdfminEs(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdfminEs(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdfminEs(I,:)='  ';
        end
        DISSc.Scaled.fminEs(I)=NaN;
        [DISSc.Scaled.fmin(I),DISSc.Scaled.qdfmin(I,:)]=fmincalc(DISSc.Scaled,I);
end
close(gcbf);
DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
end

function qdfinishH(src,~)
global gui DISSc
I=DISSc.ionogram;
Var=gui.varlyrheight.String;
gui.nonumheight=false;
switch Var
    case 'E layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhE(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhE(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhE(I,:)='  ';
        end
    case 'E2 layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhE2(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhE2(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhE2(I,:)='  ';
        end
    case 'F layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhF(I,:)='  ';
        end
    case 'F1 layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhF(I,:)='  ';
        end
    case 'F2 layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhF2(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhF2(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhF2(I,:)='  ';
        end
    case 'Es layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhEs(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhEs(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhEs(I,:)='  ';
        end
end 
close(gcbf)
DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
end

function TEsfcn(src,~)
    global DISSc
    I=DISSc.ionogram;
    aux=length(src.String);
    switch aux
        case 1
            DISSc.Scaled.TypeEs(I)=['    ' upper(src.String)];
        case 2
            DISSc.Scaled.TypeEs(I,:)=['   ' upper(src.String)];
        case 3
            DISSc.Scaled.TypeEs(I,:)=['  ' upper(src.String)];
        case 4
            DISSc.Scaled.TypeEs(I,:)=[' ' upper(src.String)];
        case 5
            DISSc.Scaled.TypeEs(I,:)=upper(src.String);
        otherwise
            DISSc.Scaled.TypeEs(I,:)='     ';
    end
    close(gcbf)
    DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
end

function qdfinishH2(src,~)
global gui DISSc
I=DISSc.ionogram;
Var=gui.varlyrheight.String;
gui.nonumheight=true;
switch Var
    case 'E layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhE(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhE(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhE(I,:)='  ';
        end
        DISSc.Scaled.hE(I)=NaN;
    case 'E2 layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhE2(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhE2(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhE2(I,:)='  ';
        end
        DISSc.Scaled.hE2(I)=NaN;
    case 'F layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhF(I,:)='  ';
        end
        DISSc.Scaled.hF(I)=NaN;
    case 'F1 layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhF(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhF(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhF(I,:)='  ';
        end
        DISSc.Scaled.hF(I)=NaN;
    case 'F2 layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhF2(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhF2(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhF2(I,:)='  ';
        end
        DISSc.Scaled.hF2(I)=NaN;
    case 'Es layer'
        if size(src.String,2)==1
            DISSc.Scaled.qdhEs(I,:)=upper([' ' src.String]);
        elseif size(src.String,2)==2
            DISSc.Scaled.qdhEs(I,:)=upper(src.String);
        else
            DISSc.Scaled.qdhEs(I,:)='  ';
        end
        DISSc.Scaled.hEs(I)=NaN;
end 
close(gcbf)
DISSc.display=DISS_display(DISSc.Scaled,DISSc.ionogram,DISSc.display);
end

function fhsel(src,~)
    global DISSc
    DISSc.fH=str2num(src.String);
    close(gcbf)
end

%Close function that saves data
function closeDISS(src,~)
    global gui DISSc
    version_DISS=src.Name(9:end);
    gui.endfig = questdlg('Do you want to save the scaled data?',...
                          ['DISS v. ' version_DISS],...
                          'Yes','No','Cancel','Yes');
    switch gui.endfig
        case 'Yes'
        answ = inputdlg('Enter scaler initials:',...
            ['DISS v. ' version_DISS]);
        if ~isempty(answ)
            if ~isempty(answ{1})
                gui.Scaler=answ{1};
            else
                gui.Scaler='????';
            end
        else
            return
        end
        DISS_savedata(gui.yy,gui.mm,gui.dd,DISSc.hh,DISSc.mm,DISSc.ss,...
            DISSc.Scaled,DISSc.fH,DISSc.statname,gui.ionclass,gui.Scaler);
        case 'Cancel'
            return
    end
    closereq;
end
