function an=DISS_display(Sc,I,an)
    if nargin==3
        delete(an)
    end
    Pos=[0 0.2 0.15 0.74];
    FN=fieldnames(Sc);
    summary{1}='─────────────────────';
    summary{2}='';
    for i=2:3
        summary{i+1}=sprintf('%9s :  %5s%2s',FN{2*i-3},num2str(Sc.(FN{1+2*(i-2)})(I),'%5.2f'),Sc.(FN{2+2*(i-2)})(I,:));
    end
    
    summary{5}='';
    summary{6}=summary{1};
    summary{7}='';
    
    for i=4:5
        if i==4
            summary{i+4}=sprintf('%9s :  %5s%2s',FN{2*i-3},num2str(Sc.(FN{1+2*(i-2)})(I),'%5.2f'),Sc.(FN{2+2*(i-2)})(I,:));
        else
            summary{i+4}=sprintf('%9s :  %5s%2s',FN{2*i-3},num2str(Sc.(FN{1+2*(i-2)})(I),'%5.2f'),' ');
        end
    end
    
    for i=8:9
        summary{i+2}=sprintf('%9s : %6s%2s',FN{i+(i-8)},num2str(Sc.(FN{i+(i-8)})(I),'%5.2f'),Sc.(FN{i+(i-8)+1})(I,:));
    end
    summary{12}=sprintf('%9s :  %5s%2s',FN{12},Sc.(FN{12})(I,:),' ');
    
    summary{13}='';
    summary{14}=summary{1};
    summary{15}='';
    c=16;
    for i=13:2:21
        summary{c}=sprintf('%9s :  %5s%2s',FN{i},num2str(Sc.(FN{i})(I),'%5.2f'),Sc.(FN{i+1})(I,:));
        c=c+1;
    end
    
    summary{21}='';
    summary{22}=summary{1};
    summary{23}='';
    
    c=24;
    for i=23:2:39
        summary{c}=sprintf('%9s :  %5s%2s',FN{i},num2str(Sc.(FN{i})(I),'%5.2f'),Sc.(FN{i+1})(I,:));
        c=c+1;
    end
    
    summary{33}='';
    summary{34}=summary{1};
    summary{35}='';
    
    summary{36}=sprintf('%9s :%9s',FN{41},num2str(Sc.(FN{41})(I),'%9.1f'));
    summary{37}=sprintf('%9s:%9s',[FN{42} '(POLAN)'],num2str(Sc.(FN{42})(I),'%9.3f'));
    
    summary{38}='';
    summary{39}=summary{1};

    an=annotation('Textbox',Pos,'String',summary,'FontName','FixedWidth',...
        'FitBoxToText','on','FontWeight','bold');
end