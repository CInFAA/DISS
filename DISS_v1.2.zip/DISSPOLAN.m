function [F,H,GWDat]=DISSPOLAN(xpos,ypos,name,d_path,fH)

n_pix=(639/9); %X Separation between ticks
n_height=480/8; %Y Separation between ticks

intvf=round(1.0054295.^(0:616),2); %Extracted from DIGION. Pixel2Frequency
VH=[];
for j=0:7
    aux=linspace(0,100,57);
    VH=[VH aux(1:(end-1))+100.*j];
end
VH=fliplr(round(VH,2)); %Pixel2VirtualHeight

skipf=[];
for i=1:9
    skp=fix(linspace(1+(64*(i-1)),64*i,n_pix));
    skipf=[skipf,skp]; %#ok<*AGROW>
end
% In virtual height, we do something similar to avoid non-real values.
skiph=[];
for i=1:8
    skph=fix(linspace(1+(56*(i-1)),56*i,n_height));
    skiph=[skiph,skph];
end

Freq=intvf(skipf);
Height=VH(skiph);


xfixed=xpos(~isnan(xpos));
yfixed=ypos(~isnan(ypos));

F=Freq(xfixed);
H=Height(yfixed);

Pos=[F',H'];
Pos=unique(Pos,'rows');

[Fb,Hb]=ionbin(name,d_path);

Data=[Fb',Hb'];


e_ind=find(Data(:,2)>770 | Data(:,2)<50);
e_ind2=find(Data(:,1)>20 | Data(:,1)<1.3);
   
y_ind=find(Data(:,1)>1.55 & Data(:,1)<1.86 & Data(:,2)>690 & Data(:,2)<760);
n_ind=find(Data(:,1)>1 & Data(:,1)<1.6 & Data(:,2)>690 & Data(:,2)<760);
doy_ind=find(Data(:,1)>2.01 & Data(:,1)<2.7 & Data(:,2)>690 & Data(:,2)<760);
h_ind=find(Data(:,1)>2.8 & Data(:,1)<4.2 & Data(:,2)>690 & Data(:,2)<760);
    
Data(e_ind,1:2)=NaN; Data(e_ind2,1:2)=NaN;
Data(y_ind,1:2)=NaN; Data(doy_ind,1:2)=NaN; %#ok<*FNDSB>
Data(h_ind,1:2)=NaN; Data(n_ind,1:2)=NaN;


err_h=8;
for i=1:length(Pos)
   [~,ind1]=min(abs(Pos(i,1)-Data(:,1)));
   aux1=Data(:,1)==Data(ind1,1);
   aux2=Data(aux1,2);
   [~,ind2]=min(abs(Pos(i,2)-aux2));
   aux3=find(Data(:,1)==Data(ind1,1) & Data(:,2)==aux2(ind2),1);
   Posadj(i,:)=Data(aux3,1:2);
   if Posadj(i,2)<Pos(i,2)+err_h || Posadj(i,2)>Pos(i,2)-err_h
       Posadj(i,2)=NaN;
   end
end
Sel_val=unique(Posadj,'rows');

st_F=2:8;
err_f=0.03;
for f_st=1:length(st_F)
    f_save=Sel_val(Sel_val(:,1)>(st_F(f_st)-err_f) & Sel_val(:,1)<(st_F(f_st)+err_f),1:2);
    if length(f_save)>1
        [~,indf]=min(abs(f_save(:,1)-st_F(f_st)));
        f_save=f_save(indf,:);
    elseif isempty(f_save)
        f_save=NaN(1,2);
    end
    GWDat(1,f_st)=f_save(1,2);
end

aux1=find(Pos(:,1)<=4);
aux2=find(Pos(:,1)>4);
auxA=Pos(aux1,1:2); 
auxB=Pos(aux2,1:2); 

auxA=auxA(1:3:length(aux1),1:2);
auxB=auxB(1:2:length(aux2),1:2);

Pos=[auxA;auxB];


fB = -fH;

pid=fopen('/home/maskedk/Escritorio/DISS/polpath.txt','w');
fprintf(pid,'%s',pwd);
fclose(pid);
file = fopen([pwd '/polanin.dat'],'wt');

fprintf(file,'%s\n',['Chapman Layer, E + F.    ' num2str(fB) '  30.   0.   0.    0']);
fprintf(file,'%3s freq ',name(10:15));
fprintf(file,'%5.2f ', Pos(:,1));
fprintf(file,'\n');


fprintf(file,'%3s hprime ',name(10:15));
fprintf(file,'%5.1f ', Pos(:,2));
fprintf(file,'\n\n\n-9');

fclose(file);

wine32='/usr/lib/wine/wineserver32';
[~,~]=system(wine32);
[~,result] = system('cd /home/maskedk/Escritorio/IPS-42/scaler2/scaler2/ && ./polan.sh');
polan_rslt=[];
try
    res=strsplit(result,'\n');
    for i=7:length(res)
        polan_rslt=[polan_rslt;res{i}];
    end
    polan_rslt = str2num(polan_rslt);
catch
    polan_rslt=[];
end

if exist([pwd '/Polan_Data'],'dir')~=7
   mkdir([pwd '/Polan_Data']) 
end

if size(polan_rslt)==0
    F = [];
    H = [];
else
    F = polan_rslt(:,1);
    H = polan_rslt(:,2);
    FH_id=fopen([pwd '/Polan_Data/THeight' name(1:15) '.dat'],'w');
    for i3=1:length(F)
        fprintf(FH_id,'%3.2f %3.2f\n',F(i3),H(i3));
    end
end


end