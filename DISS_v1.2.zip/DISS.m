clear all; %#ok
close all; clc

version='1.2';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% DISS v 1.2.0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%
% Author: B. Urra (benjaurra@udec.cl)
% DGEO, UdeC.
%
% Used as a scaling tool to obtain data from IPS-42 ionograms.
%
% Changelog 1.2:
% > POLAN true height algorithm is included, using an executable that was
%   used by V. Paznukov script. Using mouse generated trace, we obtain
%   frequencies and virtual heights to calculate real height profiles.
% > Furthermore, we now select certain fixed frecuencies (2-8 MHz) to
%   be used.
% > Style and appareance changes.
% > Now generate a single archive per day.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global L datapath Sc_master

dpath=questdlg('Welcome to DISS. Please choose your directory.'...
    ,['DISS v.' version],'Use DISSpath.txt','Select manually','Use DISSpath.txt');
if strcmp(dpath,'Select manually')
    datapath=uigetdir('','Select data folder');
    if datapath==0
       return; 
    end
else
    auxpath=importdata('DISSpath.txt');
    datapath=auxpath{1};
end

%datapath='/home/maskedk/Escritorio/IPS-42/Data'; % where the data is storaged


cor_for=false;
msg0={'Select the year (e.g. 2018):','Select a month (e.g. June => 06)',...
    'Select the day (e.g. 09)'};



while ~cor_for
    Scal_date=inputdlg(msg0,['DISS v. ' version]);
    if isempty(Scal_date)
        clear;
        return;
    end
    if ~isletter(Scal_date{1}) | ~isletter(Scal_date{2}) | ~isletter(Scal_date{3}) %#ok<OR2>
        YY=Scal_date{1};
        MM=Scal_date{2};
        DD=Scal_date{3};
        cor_for=true;
    else
        if isempty(Scal_date{1}) || isempty(Scal_date{2}) || isempty(Scal_date{3})
            uiwait(errordlg('Empty values. Please, try again','Error'))
            continue;
        end
        uiwait(errordlg('Invalid date format. Please, try again','Error'))
        continue;
    end
end

ds=filesep;

dateion=[ds YY ds MM ds DD];

n=1;

% global variables
global control l1 l0 step ctrl;
global calibration mode c scaling;
global savemode nonumber fH F_p H_p;
global X Y GWData POLANctrl VFilt;

Sc_master=true;
VFilt=false;

c=struct();
% Cursor variables
c.foF=143; c.fmin=72; c.hF=380; c.M3000=-20;
c.foE=107; c.foF1=178; c.foF2=214;
c.hE=420; c.hF1=360; c.hF2=300;

c.ftEs=107; c.hEs=420; c.fbEs=84;
% Ionogram movement
c.ion=n;

% Variables to different modes
c.nm=1;
c.dm=1;
c.em=1;

b_ion=false;

nmvar={'fmin','foF','hF','M3000'};
dmvar={'fmin','foE','foF1','foF2','hE','hF1','hF2','M3000'};
emvar={'ftEs','fbEs','hEs','TypeEs'};

msg1='Enter Qualifying/Descriptive Letter (Leave it blank if none)';
msg2='Enter Type Es';
mode='';
% Control values
calibration=false;
ctrl=false;
scaling=true;
step=1; %To control the cursor movement
savemode=false;
nonumber=false;
% Calibration values
l0=0;
l1=0;
control=true;

Var_names={'fmin','ftEs','fbEs','h''Es','foE','h''E','foF1','foF2','M3000','h''F','h''F2','hmF2'};
Var_names2={'fmin','ftEs','fbEs','hEs','foE','hE','foF1','foF','M3000','hF','hF2','hmF2'};

ax_box=71*(0:9)+1; %X Axis ticks
ay_box=[1 60*(1:8)]; %Y Axis ticks
n_pix=(639/9); %X Separation between ticks
n_height=480/8; %Y Separation between ticks

intvf=round(1.0054295.^(0:616),2); %Extracted from DIGION. Pixel2Frequency
VH=[];
for j=0:7
    aux=linspace(0,100,57);
    VH=[VH aux(1:(end-1))+100.*j];
end
VH=fliplr(round(VH,2)); %Pixel2VirtualHeight

%% Skip vector
%  To avoid any class of "non-existant" frequency on the spectrum used by
%  the IPS 42, we create a "skip vector" that allows the cursor to move
%  only on real frequencies used by the ionosonde.
skipf=[];
for i=1:9
    skp=fix(linspace(1+(64*(i-1)),64*i,n_pix));
    skipf=[skipf,skp]; %#ok<*AGROW>
end
% In virtual height, we do something similar to avoid non-real values.
skiph=[];
for i=1:8
    skph=fix(linspace(1+(56*(i-1)),56*i,n_height));
    skiph=[skiph,skph];
end

VH_mf=[200 250 300 350 400:100:700];
for z=1:length(VH_mf)
    VH_MF(z)=find(VH(skiph)==VH_mf(z),1);
end
MUF=[4.55 4.04 3.65 3.33 3.08 2.69 2.4 2.2 2.04];
Equiv_MF=fliplr(intvf(skipf));

mf1=find(Equiv_MF==4.55,1); mf2=find(Equiv_MF==4.04,1);
mf3=find(Equiv_MF==3.65,1); mf4=find(Equiv_MF==3.33,1);
mf5=find(Equiv_MF==3.08,1); mf6=find(Equiv_MF==2.69,1);
mf7=find(Equiv_MF==2.4,1); mf8=find(Equiv_MF==2.2,1);
MF=[mf1,mf2,mf3,mf4,mf5,mf6,mf7,mf8];

% fH: Gyrofrequency
fH=0.65;

% Mouse selection vectors
X(1:640)=NaN;
Y(1:640)=NaN;

%%
fig=figure(1);
set(fig, 'Position', get(0, 'Screensize'));
set(fig,'KeyPressFcn',@ctrlmode1,'KeyReleaseFcn',@ctrlmode2)

btn1 = uicontrol('Style', 'togglebutton', 'String', 'True Height',...
        'Units','normalized','Position', [0.02 0.1 0.08 0.03],...
        'Callback',@buttonpressed,'HitTest','off');

while Sc_master
    dirlist=dir([datapath dateion]);
    for i1=3:length(dirlist)
         L{i1-2}=dirlist(i1).name;
         if isempty(str2num(L{i1-2}(14:15)))
             sec_t='00';
         else
             sec_t=L{i1-2}(14:15);
         end
         t_scal(i1-2,:)=[L{i1-2}(1:4) ' ' L{i1-2}(5:6) ' ' L{i1-2}(7:8) ' ' ...
             L{i1-2}(10:11) ' ' L{i1-2}(12:13) ' ' sec_t];
    end
    Ml=length(L);
    %% Preallocating variables. If we already have scaled data, it's obtained.
    %
    try
        % Frequencies
        [~,Numdata,QDletters]=DISSext([YY MM DD]);
        fmin=Numdata.fmin; foE=Numdata.foE; foF1=Numdata.foF1; foF=Numdata.foF;
        ftEs=Numdata.ftEs; fbEs=Numdata.fbEs; M3000=Numdata.M3000; hmF2=Numdata.hmF2;
        % Virtual Heights
        hE=Numdata.hE; hF=Numdata.hF; hF2=Numdata.hF2; hEs=Numdata.hEs; 
        % QD Letters
        qdfmin=QDletters.qdfmin; qdfoE=QDletters.qdfoE; qdfoF1=QDletters.qdfoF1;
        qdfoF=QDletters.qdfoF; qdM3000=QDletters.qdM3000; qdfbEs=QDletters.qdfbEs;
        qdhE=QDletters.qdhE; qdhF=QDletters.qdhF; qdhF2=QDletters.qdhF2;
        qdhEs=QDletters.qdhEs;
        typeEs=QDletters.TypeEs;
    catch
        % Frequencies
        fmin=NaN(Ml,1); foE=NaN(Ml,1); foF1=NaN(Ml,1); foF=NaN(Ml,1);
        ftEs=NaN(Ml,1); fbEs=NaN(Ml,1); M3000=NaN(Ml,1);
        % Virtual Heights
        hE=NaN(Ml,1); hF=NaN(Ml,1); hF2=NaN(Ml,1); hEs=NaN(Ml,1); 
        % QD Letters
        qdfmin=repmat('  ',Ml,1); qdfoE=repmat('  ',Ml,1); qdfoF1=repmat('  ',Ml,1);
        qdfoF=repmat('  ',Ml,1); qdM3000=repmat('  ',Ml,1); qdfbEs=repmat('  ',Ml,1);
        qdhE=repmat('  ',Ml,1); qdhF=repmat('  ',Ml,1); qdhF2=repmat('  ',Ml,1);
        qdhEs=repmat('  ',Ml,1);
        % Type Es
        typeEs=repmat('      ',Ml,1);
        % Real Height
        hmF2=NaN(Ml,1);
    end
    % Fixed Frequencies Data
    try
        FData=load([pwd ds 'GWData' ds 'GW' YY MM DD '.dat']);
        GWData=FData(:,7:13);
    catch
        GWData=NaN(Ml,7);
    end
    
while scaling
    I=imread([datapath dateion ds L{c.ion}]);
    Ib=imbinarize(imcomplement(I),'adaptive','Sensitivity',0.05);
    %Tr=strel('diamond',3);
    %Im=imerode(Ib,Tr);
    Im=bwmorph(Ib,'thin',2);
    control=true;
    YY=L{c.ion}(1:4);
    MM=L{c.ion}(5:6);
    DD=L{c.ion}(7:8);
    
    hh=L{c.ion}(10:11);
    mm=L{c.ion}(12:13);
    ss=L{c.ion}(14:15);
    if isempty(str2num(ss))
        ss='00';
    end
    %% Color shows the part of the day
    if str2num(hh)==0
        if str2num(mm)<5
            set(gcf,'Color',[1 0.9 0.6])
        else
            set(gcf,'Color',[0.85 0.85 0.85])
        end
    elseif str2num(hh)>0 && str2num(hh)<10
        set(gcf,'Color',[0.85 0.85 0.85])
    elseif str2num(hh)>=10 && str2num(hh)<12
        set(gcf,'Color',[1 0.9 0.6])
    elseif str2num(hh)==12
        if str2num(mm)<5
            set(gcf,'Color',[1 0.9 0.6])
        else
            set(gcf,'Color',[0.75 0.75 1])
        end
    elseif str2num(hh)>12 && str2num(hh)<20
        set(gcf,'Color',[0.75 0.75 1])
    elseif str2num(hh)>=20 && str2num(hh)<=23
        set(gcf,'Color',[1 0.9 0.6])
    end
    
    POLANctrl=true;
    
    while control
        cla;
        if VFilt
            image(imcomplement(Im)); colormap(gray(2));
        else
            image(I)
            colormap(gray(256));
        end
        hold on
        grid on
        xlabel('Frequency [MHz]')
        ylabel('Virtual Height [km]')
        set(gca,'XTick',ax_box(2:end-1)+l0);
        set(gca,'XTickLabels',round(intvf(skipf(ax_box(2:end-1))),2));
        set(gca,'YTick',ay_box(1:end-1)+l1);
        set(gca,'YTickLabels',800:-100:100);
        axis([1 size(I,2) 1 size(I,1)]);
        title([YY '-' MM '-' DD '  ' hh ':' mm ':' ss ],'FontSize',12);
        
        %Display the mode
        if ~isempty(mode)
            switch mode
                case 'daymode'
                    text(0.10,1.03,mode,'Units','normalized','FontWeight','bold','Fontsize',12,'Color',[0.5 0.5 1])
                case 'nightmode'
                    text(0.10,1.03,mode,'Units','normalized','FontWeight','bold','Fontsize',12,'Color',[0 0 0.5])
                case 'sporadicmode'
                    text(0.10,1.03,mode,'Units','normalized','FontWeight','bold','Fontsize',12,'Color',[0 0.85 0.85])
            end
        end
        
        for i_tb=1:length(Var_names)
            numval=eval([Var_names2{i_tb} '(c.ion)']);
            if isnan(numval)
               val_t='  -  ';
            else
               val_t=num2str(numval,'%5.2f');
            end
            if strcmp(Var_names{i_tb},'ftEs') || strcmp(Var_names{i_tb},'hmF2')
                T{i_tb}=sprintf('%5s : %5s',Var_names{i_tb},val_t);
            else
                T{i_tb}=sprintf('%5s : %5s %2s',Var_names{i_tb},val_t,eval(['qd' Var_names2{i_tb} '(c.ion,:)']));
            end
        end
        
        try
           T{i_tb+1}=sprintf('%6s: %6s','TypeEs',typeEs(c.ion,:));
        catch
        end
        
        if exist('An','var')~=0
            delete(An)
        end
        An=annotation('Textbox',[0.004 0.78 0.1 0.2],'String',T,'FitBoxToText','on','HorizontalAlignment','center','FontWeight','bold','FontSize',8);
        
        %% Calibration section. If it's in 'calibration mode', this will run.
        if calibration
            plot((1:640)+l0,ones(1,640).*(1+l1),'Color',[0 0 1],'LineWidth',2);  %#ok<*UNRCH>
            plot(ones(1,480).*1+l0,(1:480)+l1,'Color',[0 0 1],'LineWidth',2);
            plot(ones(1,480).*640+l0,(1:480)+l1,'Color',[0 0 1],'LineWidth',2);
            for l=2:9
                plot((ones(1,15).*ax_box(l))+l0,(1:15)+l1,...
                    (ones(1,15).*ax_box(l))+l0,-((1:15)-480)+l1,...
                    'Color',[0 0 1],'LineWidth',2);
                plot((1:15)+l0,(ones(1,15).*ay_box(l-1))+l1,...
                    -((1:15)-640)+l0,(ones(1,15).*ay_box(l-1))+l1,...
                    'Color',[0 0 1],'LineWidth',2);
            end
            plot((1:640)+l0,ones(1,640).*(480+l1),'Color',[0 0 1],'LineWidth',2);
            waitforbuttonpress;
            continue; % To mantain the 'calibration mode' until it's off.
        end
        try 
            hmF2(c.ion)=DISS_Polplot(F_p{c.ion},H_p{c.ion},L{c.ion},POLANctrl);
            POLANctrl=false;
        catch
            try
                ppdir=[pwd ds 'POLPLOTS' ds YY ds MM ds DD ds 'pp' hh mm ss '.mat'];
                load(ppdir);
                plot(indf,indh,':','Color',[0.3 0.3 0.3],'LineWidth',2);
            catch
            end
        end
        switch mode
            case 'nightmode'
                switch c.nm
                    case 1
                        text(-0.03,1.03,nmvar{c.nm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(nmvar{c.nm}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.fmin=plot(ones(1,240).*(c.fmin+l0),(241:480)+l1,'Color',[0 0 1]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    fmin(c.ion,:)=intvf(skipf(c.fmin)); %#ok<*SAGROW>
                                else
                                    fmin(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdfmin(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdfmin(c.ion,:)=qd{1};
                                else
                                    qdfmin(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 2
                        text(-0.03,1.03,nmvar{c.nm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(nmvar{c.nm}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.foF=plot(ones(1,480).*(c.foF+l0),(1:480)+l1,'Color',[1 0 0]);
                        [~,c.foF_b]=min(abs(intvf(skipf)-(intvf(skipf(c.foF))+fH/2)));
                        P.foF_b=plot(ones(1,480).*(c.foF_b+l0),(1:480)+l1,'--','Color',[1 0 0]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    foF(c.ion,:)=intvf(skipf(c.foF)); %#ok<*SAGROW>
                                else
                                    foF(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdfoF(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdfoF(c.ion,:)=qd{1};
                                else
                                    qdfoF(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 3
                        text(-0.03,1.03,nmvar{c.nm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.06,1.03,num2str(VH(skiph(c.(nmvar{c.nm}))),'%5.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.hF=plot((1:640)+l0,ones(1,640).*(c.hF+l1),'Color',[0 0.75 0.75]);
                        P.hF_e=plot((1:640)+l0,ones(1,640).*[(3.*(c.hF) - 480*2 + l1);(2.*(c.hF) - 480 + l1)]...
                            ,'--','Color',[0 0.75 0.75]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    hF(c.ion,:)=VH(skiph(c.hF)); %#ok<*SAGROW>
                                else
                                    hF(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdhF(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdhF(c.ion,:)=qd{1};
                                else
                                    qdhF(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 4
                        text(-0.03,1.03,nmvar{c.nm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.07,1.03,num2str(Equiv_MF(c.foF-c.M3000),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.M3000=plot(MF+c.M3000+l0,VH_MF+l1,'m');
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    M3000(c.ion,:)=Equiv_MF(c.foF-c.M3000); %#ok<*SAGROW>
                                else
                                    M3000(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdM3000(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdM3000(c.ion,:)=qd{1};
                                else
                                    qdM3000(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                end
            case 'daymode'
                switch c.dm
                    case 1
                        P.fmin=plot(ones(1,240).*(c.fmin+l0),(241:480)+l1,'Color',[0 0 1]);
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(dmvar{c.dm}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    fmin(c.ion,:)=intvf(skipf(c.fmin)); %#ok<*SAGROW>
                                else
                                    fmin(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdfmin(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdfmin(c.ion,:)=qd{1};
                                else
                                    qdfmin(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 2
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(dmvar{c.dm}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.foE=plot(ones(1,480).*(c.foE+l0),(1:480)+l1,'Color',[0 1 0]);
                        [~,c.foE_b]=min(abs(intvf(skipf)-(intvf(skipf(c.foE))+fH/2)));
                        P.foE_b=plot(ones(1,480).*(c.foE_b+l0),(1:480)+l1,'--','Color',[0 1 0]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    foE(c.ion,:)=intvf(skipf(c.foE)); %#ok<*SAGROW>
                                else
                                    foE(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdfoE(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdfoE(c.ion,:)=qd{1};
                                else
                                    qdfoE(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 3
                        P.foF1=plot(ones(1,480).*(c.foF1+l0),(1:480)+l1,'Color',[1 0 0]);
                        [~,c.foF1_b]=min(abs(intvf(skipf)-(intvf(skipf(c.foF1))+fH/2)));
                        P.foF1_b=plot(ones(1,480).*(c.foF1_b+l0),(1:480)+l1,'--','Color',[1 0 0]);
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(dmvar{c.dm}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    foF1(c.ion,:)=intvf(skipf(c.foF1)); %#ok<*SAGROW>
                                else
                                    foF1(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdfoF1(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdfoF1(c.ion,:)=qd{1};
                                else
                                    qdfoF1(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 4
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(dmvar{c.dm}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.foF2=plot(ones(1,480).*(c.foF2+l0),(1:480)+l1,'Color',[0.5 0 0]);
                        [~,c.foF2_b]=min(abs(intvf(skipf)-(intvf(skipf(c.foF2))+fH/2)));
                        P.foF2_b=plot(ones(1,480).*(c.foF2_b+l0),(1:480)+l1,'--','Color',[0.5 0 0]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    foF(c.ion,:)=intvf(skipf(c.foF2)); %#ok<*SAGROW>
                                else
                                    foF(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdfoF(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdfoF(c.ion,:)=qd{1};
                                else
                                    qdfoF(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 5
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.06,1.03,num2str(VH(skiph(c.(dmvar{c.dm}))),'%5.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.hE=plot((1:640)+l0,ones(1,640).*(c.hE+l1),'Color',[0.75 0.75 0.75]);
                        P.hE_e=plot((1:640)+l0,ones(1,640).*[(3.*(c.hE) - 480*2 + l1);(2.*(c.hE) - 480 + l1)]...
                            ,'--','Color',[0.75 0.75 0.75]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    hE(c.ion,:)=VH(skiph(c.hE)); %#ok<*SAGROW>
                                else
                                    hE(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdhE(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdhE(c.ion,:)=qd{1};
                                else
                                    qdhE(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 6
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.06,1.03,num2str(VH(skiph(c.(dmvar{c.dm}))),'%5.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.hF1=plot((1:640)+l0,ones(1,640).*(c.hF1+l1),'Color',[0 0.75 0.75]);
                        P.hF1_e=plot((1:640)+l0,ones(1,640).*[(3.*(c.hF1) - 480*2 + l1);(2.*(c.hF1) - 480 + l1)]...
                            ,'--','Color',[0 0.75 0.75]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    hF(c.ion,:)=VH(skiph(c.hF1)); %#ok<*SAGROW>
                                else
                                    hF(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdhF(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdhF(c.ion,:)=qd{1};
                                else
                                    qdhF(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 7
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.06,1.03,num2str(VH(skiph(c.(dmvar{c.dm}))),'%5.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.hF2=plot((1:640)+l0,ones(1,640).*(c.hF2+l1),'Color',[0 0.5 0.5]);
                        P.hF2_e=plot((1:640)+l0,ones(1,640).*[(3.*(c.hF2) - 480*2 + l1);(2.*(c.hF2) - 480 + l1)]...
                            ,'--','Color',[0 0.5 0.5]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    hF2(c.ion,:)=VH(skiph(c.hF2)); %#ok<*SAGROW>
                                else
                                    hF2(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdhF2(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdhF2(c.ion,:)=qd{1};
                                else
                                    qdhF2(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 8
                        text(-0.03,1.03,dmvar{c.dm},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.07,1.03,num2str(Equiv_MF(c.foF2-c.M3000),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.M3000=plot(MF+c.M3000+l0,VH_MF+l1,'m');
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    M3000(c.ion,:)=Equiv_MF(c.foF2-c.M3000); %#ok<*SAGROW>
                                else
                                    M3000(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdM3000(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdM3000(c.ion,:)=qd{1};
                                else
                                    qdM3000(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                end
            case 'sporadicmode'
                switch c.em
                    case 1
                        text(-0.03,1.03,emvar{c.em},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(emvar{c.em}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.ftEs=plot(ones(1,240).*(c.ftEs+l0),(241:480)+l1,'Color',[0 1 1]);
                        if savemode
                            ftEs(c.ion,:)=intvf(skipf(c.ftEs)); %#ok<*SAGROW>
                            savemode=false;
                        if nonumber
                            ftEs(c.ion,:)=NaN;
                            nonumber=false;
                        end
                        end
                    case 2
                        text(-0.03,1.03,emvar{c.em},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.05,1.03,num2str(intvf(skipf(c.(emvar{c.em}))),'%2.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.fbEs=plot(ones(1,240).*(c.fbEs+l0),(241:480)+l1,'Color',[0 0 0.5]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    fbEs(c.ion,:)=intvf(skipf(c.fbEs)); %#ok<*SAGROW>
                                else
                                    fbEs(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdfbEs(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdfbEs(c.ion,:)=qd{1};
                                else
                                    qdfbEs(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 3
                        text(-0.03,1.03,emvar{c.em},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        text(0.06,1.03,num2str(VH(skiph(c.(emvar{c.em}))),'%5.2f'),...
                            'Units','normalized','Fontsize',12,'FontWeight',...
                            'Bold','HorizontalAlignment','center');
                        P.hEs=plot((1:640)+l0,ones(1,640).*(c.hEs + l1),'Color',[0.25 0.25 0.25]);
                        P.hEs_e=plot((1:640)+l0,ones(1,640).*[(3.*(c.hEs) - 480*2  + l1);(2.*(c.hEs) - 480 + l1)]...
                            ,'--','Color',[0.25 0.25 0.25]);
                        if savemode
                            qd=inputdlg(msg1);
                            if ~isempty(qd)
                                if ~nonumber
                                    hEs(c.ion,:)=VH(skiph(c.hEs)); %#ok<*SAGROW>
                                else
                                    hEs(c.ion,:)=NaN;
                                end
                                if length(qd{1})==1
                                    qdhEs(c.ion,:)=[' ' qd{1}];
                                elseif ~isempty(qd{1})
                                    qdhEs(c.ion,:)=qd{1};
                                else
                                    qdhEs(c.ion,:)='  ';
                                end
                            end
                            savemode=false;
                            nonumber=false;
                        end
                    case 4
                        text(-0.03,1.03,emvar{c.em},'Units','normalized',...
                            'Fontsize',12,'FontWeight','Bold');
                        if savemode
                            if nonumber
                               nonumber=false;
                               continue;
                            end
                            qd=inputdlg(msg2);
                            if ~isempty(qd)
                                switch length(qd{1})
                                    case 1
                                        typeEs(c.ion,:)=[qd{1} '     '];
                                    case 2
                                        typeEs(c.ion,:)=[qd{1} '    '];
                                    case 3
                                        typeEs(c.ion,:)=[qd{1} '   '];
                                    case 4
                                        typeEs(c.ion,:)=[qd{1} '  '];
                                    case 5
                                        typeEs(c.ion,:)=[qd{1} ' '];
                                    otherwise
                                        uiwait(errordlg('Invalid Type Es format. Please, try again'))
                                end
                            else
                                typeEs(c.ion,:)='     ';
                            end
                            savemode=false;
                        end
                end
        end
        jk=waitforbuttonpress;
        if isempty(mode)
            set(btn1,'Enable','on')
        else
            set(btn1,'Enable','off')
        end
    end
end
end
close;

%% Ask about saving scaling data
saving=questdlg('Do you want to save scaled data?'...
    ,['DISS v.' version],'Yes','No','Yes');
if strcmp(saving,'No')
    return;
end

options.Resize='off';
sn=inputdlg('Please input your initials','',1,{''},options);
if isempty(sn)
   sn{1}='??'; 
end

t_scal=string(t_scal);

if exist([pwd ds 'GWData'],'dir')~=7
   mkdir([pwd ds 'GWData']) 
end

%% Saving fixed frequencies information
logname_g=['GW' YY MM DD '.dat'];
F_id=fopen([pwd ds 'GWData' ds logname_g],'w');
for i2=1:length(t_scal)
    fprintf(F_id,'%s %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f\n',t_scal(i2),GWData(i2,1),GWData(i2,2),GWData(i2,3),GWData(i2,4)...
        ,GWData(i2,5),GWData(i2,6),GWData(i2,7));
end
%% Creating Directory to save scaled data
if (exist('Scaled-Data','dir')==0)
    mkdir('Scaled-Data')
end


SD=table(t_scal,fmin,...
    string(qdfmin),fbEs,string(qdfbEs),ftEs,hEs,string(qdhEs),string(typeEs),...
    foE,string(qdfoE),hE,string(qdhE),...
    foF1,string(qdfoF1),foF,string(qdfoF),M3000,string(qdM3000),...
    hF,string(qdhF),hF2,string(qdhF2),hmF2);
SD=sortrows(SD,1);

%% Preparing the scaled data archive
logname=[YY MM DD '.dat'];
id_data=fopen(['Scaled-Data' ds logname],'w');

header={['DISS v. ' version ' Scaled on ' date ' by ' sn{1}],['fH = ' num2str(fH)]};
header2={'YYYY','MM','DD','hh','mm','ss',...
    ' fmin','QD',' fbEs','QD',' ftEs','  h''Es','QD','TypeEs',...
    '  foE','QD','   h''E','QD',' foF1','QD',' foF2','QD',...
    'M3000','QD','   h''F','QD','  h''F2','QD','  hmF2'};
for u=1:2
    fprintf(id_data,'%s\n',header{u});
end

for u=1:29
    if u==29
        fprintf(id_data,'%s\n',header2{u});
        break;
    end
    fprintf(id_data,'%s ',header2{u});
end

%% Then write
for i_d=1:length(t_scal)
    fprintf(id_data,...
        '%s %5.2f %2s %5.2f %2s %5.2f %6.2f %2s %6s %5.2f %2s %6.2f %2s %5.2f %2s %5.2f %2s %5.2f %2s %6.2f %2s %6.2f %2s %6.2f\n',...
        SD.t_scal(i_d),SD.fmin(i_d,:),SD.Var3(i_d,:),SD.fbEs(i_d,:),SD.Var5(i_d,:),SD.ftEs(i_d,:),SD.hEs(i_d,:),SD.Var8(i_d,:),SD.Var9(i_d,:),...
        SD.foE(i_d,:),SD.Var11(i_d,:),SD.hE(i_d,:),SD.Var13(i_d,:),SD.foF1(i_d,:),SD.Var15(i_d,:),SD.foF(i_d,:),SD.Var17(i_d,:),...
        SD.M3000(i_d,:),SD.Var19(i_d,:),SD.hF(i_d,:),SD.Var21(i_d,:),SD.hF2(i_d,:),SD.Var23(i_d,:),SD.hmF2(i_d,:));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Callback functions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ctrlmode1(~,event)
global l0 l1 control step ctrl;
global calibration mode c scaling L Sc_master;
global savemode nonumber fH VFilt
switch event.Key
    case 'uparrow'
        if calibration
            l1=l1-step;
            return;
        end
        if strcmp(mode,'nightmode')
            switch c.nm
                case 3
                    c.hF=c.hF-step;
            end
            return;
        elseif strcmp(mode,'daymode')
            switch c.dm
                case 5
                    c.hE=c.hE-step;
                case 6
                    c.hF1=c.hF1-step;
                case 7
                    c.hF2=c.hF2-step;
            end
            return;
        elseif strcmp(mode,'sporadicmode')
            switch c.em
                case 3
                    c.hEs=c.hEs-step;
            end
            return;
        end
        c.ion=c.ion-1;
        if c.ion<1
            c.ion=1;
        end
        control=false;
    case 'downarrow'
        if calibration
            l1=l1+step;
            return;
        end
        if strcmp(mode,'nightmode')
            switch c.nm
                case 3
                    c.hF=c.hF+step;
            end
            return;
        elseif strcmp(mode,'daymode')
            switch c.dm
                case 5
                    c.hE=c.hE+step;
                case 6
                    c.hF1=c.hF1+step;
                case 7
                    c.hF2=c.hF2+step;
            end
            return;
        elseif strcmp(mode,'sporadicmode')
            switch c.em
                case 3
                    c.hEs=c.hEs+step;
            end
            return;
        end
        c.ion=c.ion+1;
        if c.ion>length(L)
            c.ion=length(L);
        end
        control=false;
    case 'leftarrow'
        if calibration
            l0=l0-step;
            return;
        end
        if strcmp(mode,'nightmode')
            switch c.nm
                case 1
                    c.fmin=c.fmin-step;
                case 2
                    c.foF=c.foF-step;
                case 4
                    c.M3000=c.M3000-step;
            end
            return;
        elseif strcmp(mode,'daymode')
            switch c.dm
                case 1
                    c.fmin=c.fmin-step;
                case 2
                    c.foE=c.foE-step;
                case 3
                    c.foF1=c.foF1-step;
                case 4
                    c.foF2=c.foF2-step;
                case 8
                    c.M3000=c.M3000-step;
            end
            return;
        elseif strcmp(mode,'sporadicmode')
            switch c.em
                case 1
                    c.ftEs=c.ftEs-step;
                case 2
                    c.fbEs=c.fbEs-step;
            end
            return;
        end
    case 'rightarrow'
        if calibration
            l0=l0+step;
            return;
        end
        if strcmp(mode,'nightmode')
            switch c.nm
                case 1
                    c.fmin=c.fmin+step;
                case 2
                    c.foF=c.foF+step;
                case 4
                    c.M3000=c.M3000+step;
            end
            return;
        elseif strcmp(mode,'daymode')
            switch c.dm
                case 1
                    c.fmin=c.fmin+step;
                case 2
                    c.foE=c.foE+step;
                case 3
                    c.foF1=c.foF1+step;
                case 4
                    c.foF2=c.foF2+step;
                case 8
                    c.M3000=c.M3000+step;
            end
            return;
        elseif strcmp(mode,'sporadicmode')
            switch c.em
                case 1
                    c.ftEs=c.ftEs+step;
                case 2
                    c.fbEs=c.fbEs+step;
            end
            return;
        end
    case 'escape'
        control=false;
        scaling=false;
        Sc_master=false;
    case 'control'
        step=8;
        if isempty('mode')==0
            ctrl=true;
        end
    case 'c'
        if ctrl
            calibration=~calibration;
        end
    case 'f1'
        if calibration
            return;
        end
        if isempty(mode)
            mode='nightmode';
        else
            mode='';
        end
    case 'f2'
        if calibration
            return;
        end
        if isempty(mode)
            mode='daymode';
        else
            mode='';
        end
    case 'f3'
        if calibration
            return;
        end
        if isempty(mode)
            mode='sporadicmode';
        else
            mode='';
        end
    case 'space'
        if strcmp(mode,'nightmode')
            c.nm=c.nm+1;
            if c.nm>4
                c.nm=1;
            end
        elseif strcmp(mode,'daymode')
            c.dm=c.dm+1;
            if c.dm>8
                c.dm=1;
            end
        elseif strcmp(mode,'sporadicmode')
            c.em=c.em+1;
            if c.em>4
                c.em=1;
            end
        end
    case 'return'
        if ~isempty(mode)
            savemode=true;
        end
    case 'delete'
        if ~isempty(mode)
            savemode=true;
            nonumber=true;
        end
    case 'g'
        fH_old=fH;
        fH=inputdlg(['fH determined as ' num2str(fH) '. Select the new value (`Cancel` won''t change it)']);
        if isempty(fH) || isempty(fH{1})
            fH=fH_old;
        else
            fH=str2num(fH{1});
        end
    case '1'
        switch mode
            case 'nightmode'
                c.nm=1;
            case 'daymode'
                c.dm=1;
            case 'sporadicmode'
                c.em=1;
        end
    case '2'
        switch mode
            case 'nightmode'
                c.nm=2;
            case 'daymode'
                c.dm=2;
            case 'sporadicmode'
                c.em=2;
        end
    case '3'
        switch mode
            case 'nightmode'
                c.nm=3;
            case 'daymode'
                c.dm=3;
            case 'sporadicmode'
                c.em=3;
        end
    case '4'
        switch mode
            case 'nightmode'
                c.nm=4;
            case 'daymode'
                c.dm=4;
            case 'sporadicmode'
                c.em=4;
        end
    case '5'
        if mode=='daymode'
            c.dm=5;
        end
    case '6'
        if mode=='daymode'
            c.dm=6;
        end
    case '7'
        if mode=='daymode'
            c.dm=7;
        end
    case '8'
        if mode=='daymode'
            c.dm=8;
        end
    case 'f'
        if ~VFilt
            VFilt=true;
        else
            VFilt=false;
        end
end
end

function ctrlmode2(~,event)
global step ctrl;
switch event.Key
    case 'control'
        step=1;
        ctrl=false;
end
end

function buttonpressed(src,~)
    global X Y F_p H_p L c datapath
    global fH mode GWData
    ionname=L{c.ion};
    if ~isempty(mode)
       return; 
    end
    if src.Value==1
        drawDISS(gcf,X,Y);
        uiwait(gcf)
    else
        set(gcf,'WindowButtonDownFcn','')
        set(gcf,'WindowButtonMotionFcn','')
        set(gcf,'WindowButtonUpFcn','')
        B=findobj(gca,'Type','Line','Color',[1 0 0]);
        try
            fd=B.XData;
            hd=B.YData;
            [F_p{c.ion},H_p{c.ion},GWData(c.ion,:)]=DISSPOLAN(fd,hd,ionname,datapath,fH);
            uiresume(gcf)
            set(gco,'Enable','off')
        catch
            uiresume(gcf)
            set(gco,'Enable','off')
        end        
    end
end