function [Fb,Hb]=ionbin(archive,dp)
    
    n_pix=639/9;
    n_height=480/8;

    intvf=round(1.0054295.^(0:616),2); %Extracted from DIGION. Pixel2Frequency
    VH=[];
    for j=0:7
        aux=linspace(0,100,57);
        VH=[VH aux(1:(end-1))+100.*j];
    end
    VH=fliplr(round(VH,2)); %Pixel2VirtualHeight

    skipf=[];
    for i=1:9
        skp=fix(linspace(1+(64*(i-1)),64*i,n_pix));
        skipf=[skipf,skp]; %#ok<*AGROW>
    end
    % In virtual height, we do something similar to avoid non-real values.
    skiph=[];
    for i=1:8
        skph=fix(linspace(1+(56*(i-1)),56*i,n_height));
        skiph=[skiph,skph];
    end

    fv=intvf(skipf);
    hv=VH(skiph);
    
    YY=archive(1:4);
    MM=archive(5:6);
    DD=archive(7:8);
    
    ds=filesep;

    fol=[ds YY ds MM ds DD];
    I=imread([dp fol ds archive]);
    Ib=imbinarize(I,'adaptive','Sensitivity',0.7);
    [hh,ff]=find(Ib==0);
    nind=ff==640;
    hh(nind)=[]; ff(nind)=[];
    Fb=fv(ff);
    Hb=hv(hh);
end
