function [t_s,Numdata,QDletters]=DISSext(data)
% This function extract numerical and qualifying/descriptive data from
% DISS v. >1.1 output files. The function doesn't select dates or erase
% duplicated data. Use when the data is already sorted.
%
% INPUT:
%
% data: archive name without '.dat' (output file)
%
%
% OUTPUT:
%
% t_s: data datetime vector
% Numdata: struct with numerical data from scaling
% QDletters: struct with qualifying/descriptive letters from each variable
% and char vector that contains TypeEs information that was scaled.
%
%
%%
data_path=[pwd filesep 'Scaled-Data' filesep];

if ~ischar(data)
    error('Argument in function must be the name written (char vector)');
end

dataname=[data_path data '.dat'];

fid=fopen(dataname);
Scadata=textscan(fid,...
    '%4c%2c%2c%2c%2c%2c%5c%2c%5c%2c%5c%6c%2c%6c%5c%2c%6c%2c%5c%2c%5c%2c%5c%2c%6c%2c%6c%2c%6c'...
    ,'Headerlines',3,'Delimiter',' ');
fclose(fid);
YYYY=str2num(Scadata{1});
MM=str2num(Scadata{2});
DD=str2num(Scadata{3});

hh=str2num(Scadata{4});
mm=str2num(Scadata{5});
ss=str2num(Scadata{6});

% Time
t_s=datetime(YYYY,MM,DD,hh,mm,ss);

% Num Data
Numdata.fmin=str2num(Scadata{7});
Numdata.fbEs=str2num(Scadata{9});
Numdata.ftEs=str2num(Scadata{11});
Numdata.hEs=str2num(Scadata{12});
Numdata.foE=str2num(Scadata{15});
Numdata.hE=str2num(Scadata{17});
Numdata.foF1=str2num(Scadata{19});
Numdata.foF=str2num(Scadata{21});
Numdata.M3000=str2num(Scadata{23});
Numdata.hF=str2num(Scadata{25});
Numdata.hF2=str2num(Scadata{27});
Numdata.hmF2=str2num(Scadata{29});

% QD Letters
QDletters.qdfmin=Scadata{8};
QDletters.qdfbEs=Scadata{10};
QDletters.qdhEs=Scadata{13};
QDletters.qdfoE=Scadata{16};
QDletters.qdhE=Scadata{18};
QDletters.qdfoF1=Scadata{20};
QDletters.qdfoF=Scadata{22};
QDletters.qdM3000=Scadata{24};
QDletters.qdhF=Scadata{26};
QDletters.qdhF2=Scadata{28};

% Type Es
QDletters.TypeEs=Scadata{14};
return;