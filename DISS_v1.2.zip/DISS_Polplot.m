function hmF2=DISS_Polplot(F_p,H_p,name,ctrl)
    n_pix=639/9;
    n_height=480/8;

    intvf=round(1.0054295.^(0:616),2); %Extracted from DIGION. Pixel2Frequency
    VH=[];
    for j=0:7
        aux=linspace(0,100,57);
        VH=[VH aux(1:(end-1))+100.*j];
    end
    VH=fliplr(round(VH,2)); %Pixel2VirtualHeight

    skipf=[];
    for i=1:9
        skp=fix(linspace(1+(64*(i-1)),64*i,n_pix));
        skipf=[skipf,skp]; %#ok<*AGROW>
    end
    % In virtual height, we do something similar to avoid non-real values.
    skiph=[];
    for i=1:8
        skph=fix(linspace(1+(56*(i-1)),56*i,n_height));
        skiph=[skiph,skph];
    end

    fv=intvf(skipf);
    hv=VH(skiph);
    
%     try
%         H_p(1)=interp1(F_p,H_p,1,'spline');
%         F_p(1)=1;
%     catch
%     end
    [~,indhm]=max(F_p);
    hmF2=H_p(indhm);
    
    if ctrl
        if exist([pwd '/POLPLOTS'],'dir')==0
            mkdir([pwd '/POLPLOTS']);
        end
        if exist([pwd '/POLPLOTS/' name(1:4)],'dir')==0
           mkdir([pwd '/POLPLOTS/' name(1:4)]); 
        end
        if exist([pwd '/POLPLOTS/' name(1:4) '/' name(5:6)],'dir')==0
           mkdir([pwd '/POLPLOTS/' name(1:4) '/' name(5:6)]); 
        end
        if exist([pwd '/POLPLOTS/' name(1:4) '/' name(5:6) '/' name(7:8)],'dir')==0
           mkdir([pwd '/POLPLOTS/' name(1:4) '/' name(5:6) '/' name(7:8)]); 
        end
    end
    
    for i=1:length(F_p)
        [~,indf(i)]=min(abs(fv-F_p(i)));
        [~,indh(i)]=min(abs(hv-H_p(i)));
    end
    if ctrl
        dirname=[pwd '/POLPLOTS/' name(1:4) '/' name(5:6) '/' name(7:8)];
        save([dirname '/pp' name(10:15) '.mat'],'indf','indh')    
    end
    
    plot(indf,indh,':','Color',[0.3 0.3 0.3],'LineWidth',2);
end