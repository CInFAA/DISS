function drawDISS(fig,X,Y)
    set(fig,'WindowButtonDownFcn',{@start})
    function start(src,~)
        global R
        ct=get(fig,'selectiontype');
        switch ct
            case 'normal'
                try
                    delete(R)
                catch
                end
                C=get(gca,'CurrentPoint');
                xx=round(C(1,1));
                yy=round(C(1,2));
                X(xx)=xx;
                Y(xx)=yy;
                %set(R,'XData',X,'YData',Y)
                R=line(X,Y,'Color',[1 0 0],'LineWidth',3);
                set(fig,'WindowButtonMotionFcn',@drawing)
                set(fig,'WindowButtonUpFcn',{@enddraw})
            case 'alt'
                try
                    delete(R)
                catch
                end
                C=get(gca,'CurrentPoint');
                xx=round(C(1,1));
                yy=round(C(1,2));
                X(xx)=NaN;
                Y(xx)=NaN;
                R=line(X,Y,'Color',[1 0 0],'LineWidth',3);
                %set(R,'XData',X,'YData',Y)
                set(fig,'WindowButtonMotion',{@deldrawing})
                set(fig,'WindowButtonUpFcn',{@enddraw})
        end
    end
    function drawing(~,~)
        global R
        C=get(gca,'CurrentPoint');
                xx=round(C(1,1));
                yy=round(C(1,2));
                X(xx)=xx;
                Y(xx)=yy;
                set(R,'XData',X,'YData',Y)
                %R=line(X,Y,'Color',[1 0 0],'LineWidth',2);
    end
    function deldrawing(~,~)
        global R
        C=get(gca,'CurrentPoint');
                xx=round(C(1,1));
                yy=round(C(1,2));
                X(xx)=NaN;
                Y(xx)=NaN;
                set(R,'XData',X,'YData',Y)
                %R=line(X,Y,'Color',[1 0 0],'LineWidth',2);
    end
    function enddraw(src,~)
        set(fig,'WindowButtonMotionFcn','')
        set(fig,'WindowButtonUpFcn','')
    end
end