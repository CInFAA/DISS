close all; clear; clc;
%% Digitalized Ionogram Scaling Script (DISS)
%
%
%   Created by Urra B. 
%   Contact: benjaurra@udec.cl
%   
%   Department of Geophysics, Universidad de Concepcion, 2019.
%   ------------------------------------------------------------------------
%   Using the program called DIGION for IPS-42 ionogram scaling as a
%   reference, this script allows the scaler to use the user-friendly
%   enviroment that MATLAB offers in order to obtain all the possible
%   information that a ionogram could give us.
%   
%   Compared to DIGION, this script supports new parameters, a lot of
%   improvements in matter of flexibility, inputs and also how the
%   information is saved. Further improvements are: implement new
%   elements that are present in Digisonde softwares (e.g. POLAN) and also a
%   complete Toolbox that would improve the relationship between newcomers
%   in scaling and the scaling tool.
%   
%   v. 0.0.3
%   -Various improvements. Now it's in conditions to be used as a
%    replacement of DIGION 
%   
%   v. 0.0.4
%   - Callback functions to amply the options.
%
%   v. 1.0.0
%   - A replacement of DIGION, which is used as an interpreter to transform
%     compacted binary data from GETION into ionograms. Using a screenshot
%     app (e.g. Kazam on Ubuntu), the photos (640 x 480) will be the new
%     "data archive" to scaling IPS 42 gathered data.
% 
%        
%
%%
version='1.0.0';
cor_for=false;
msg0={'Select the year (e.g. 2018):','Select a month (e.g. June => 06)',...
    'Select the day (e.g. 09)'};
while ~cor_for
Scal_date=inputdlg(msg0,['DISS v. ' version]);

if isempty(Scal_date)
   clear;
   return; 
end
try
    yy=Scal_date{1}(3:4);
    mm=Scal_date{2};
    dd=Scal_date{3};
    cor_for=true;
catch
   uiwait(errordlg('Invalid date format. Please, try again'))
   continue;
end
end

if exist([yy mm dd],'dir')==0
   uiwait(errordlg(['There''s no directory called ''' yy mm dd '''/']))
   return;
end
%%
dir=[ yy mm dd '/'];
system(['ls -1 ' dir ' | grep "' yy mm '">' dir 'listion.txt']);
fid=fopen([ dir 'listion.txt']);
list=textscan(fid,'%s');

if length(list{1})<96
    uiwait(warndlg(['There''s only ' num2str(length(list{1})) ' ionograms available']));
end
%% 
% Gyro frequency is determined by:
%
% fB = 2.8 * F 
%
% where F is the Total Field on the ionogram location in Gauss. To convert
% from nT to Gs, the conversion formula is:
%
% 1 nT = 10⁻⁵ Gs
%
fB=0.65; % Gyro frequency on La Serena 2018. 

i=1; %start at ionogram 1. Changeable but innecesary considering matlab speed
%%
scaling=true;
d_digion=false;
control=0;
control2=1;
global step contfig databox
databox=[];
contfig=false;
%% Some text variables used on ui
msg1='Enter Qualifying/Descriptive Letter (Leave it blank if none)';
fprintf('Starting scaling... \n\n')

%% Preallocating all variables to have uniform data
% Numerical Data
foE=NaN(96,1); foF=NaN(96,1); foF1=NaN(96,1);
fmin=NaN(96,1); fEs=NaN(96,1);
hE=NaN(96,1); hF=NaN(96,1); hF2=NaN(96,1);
M3000=NaN(96,1);

% Letter Data
QDfoE=repmat('  ',96,1); QDfoF=repmat('  ',96,1); QDfoF1=repmat('  ',96,1);
QDfmin=repmat('  ',96,1); QDfEs=repmat('  ',96,1);
QDhE=repmat('  ',96,1); QDhF=repmat('  ',96,1); QDhF2=repmat('  ',96,1);
QDM3000=repmat('  ',96,1);
%% This recovers the last scaled data to continue and don't start over
% Of course, it always allows the scaler to edit the old scaled dataset
if exist(['ScaledData/' yy mm dd '.dat'],'file')==2
    f_Sc=fopen(['ScaledData/' yy mm dd '.dat']);
    f_Sc_l=fopen(['ScaledData/' yy mm dd '_letters.dat']);
    Dat=textscan(f_Sc,'%2d%3d%5.2f%5.2f%5.2f%5.2f%5.2f%6.2f%6.2f%6.2f%5.2f','HeaderLines',2);
    indx1=~isnan(Dat{1,3}); indx2=~isnan(Dat{1,4});
    indx3=~isnan(Dat{1,5}); indx4=~isnan(Dat{1,6});
    indx5=~isnan(Dat{1,7}); indx6=~isnan(Dat{1,8});
    indx7=~isnan(Dat{1,9}); indx8=~isnan(Dat{1,10});
    indx9=~isnan(Dat{1,11});
    
    foE(indx1)=Dat{1,3}(indx1); foF(indx2)=Dat{1,4}(indx2);
    foF1(indx3)=Dat{1,5}(indx3); fmin(indx4)=Dat{1,6}(indx4);
    fEs(indx5)=Dat{1,7}(indx5); hE(indx6)=Dat{1,8}(indx6);
    hF(indx7)=Dat{1,9}(indx7); hF2(indx8)=Dat{1,10}(indx8);
    M3000(indx9)=Dat{1,11}(indx9);
    
    Dat_l=textscan(f_Sc_l,'%2d %3d %4s %4s %4s %4s %4s %4s %4s %5s','HeaderLines',2,'Delimiter',',');
    indx1=~strcmp(Dat_l{1,3},""); indx2=~strcmp(Dat_l{1,4},"");
    indx3=~strcmp(Dat_l{1,5},""); indx4=~strcmp(Dat_l{1,6},"");
    indx5=~strcmp(Dat_l{1,7},""); indx6=~strcmp(Dat_l{1,8},"");
    indx7=~strcmp(Dat_l{1,9},""); indx8=~strcmp(Dat_l{1,10},"");
    
    
    Aux.a=char(Dat_l{1,3}(indx1)); Aux.b=char(Dat_l{1,4}(indx2));
    Aux.c=char(Dat_l{1,5}(indx3)); Aux.d=char(Dat_l{1,6}(indx4));
    Aux.e=char(Dat_l{1,7}(indx5)); Aux.f=char(Dat_l{1,8}(indx6));
    Aux.g=char(Dat_l{1,9}(indx7)); Aux.h=char(Dat_l{1,10}(indx8));
    
    for L=['a','b','c','d','e','f','g','h']
       for M=1:size(Aux.(L),1)
        if length(Aux.(L)(M,:))==1
          Aux.(L)(M,1:2)=[' ' Aux.(L)(M)];
        elseif ~isletter(Aux.(L)(M,2))
          Aux.(L)(M,1:2)=[' ' Aux.(L)(M,1)];
        end
       end
    end
    
    QDfoE(indx1,:)=Aux.a; QDfoF(indx2,:)=Aux.b;
    QDfoF1(indx3,:)=Aux.c; QDfmin(indx4,:)=Aux.d;
    QDhE(indx5,:)=Aux.e; QDhF(indx6,:)=Aux.f;
    QDhF2(indx7,:)=Aux.g; QDM3000(indx8,:)=Aux.h;
end


while scaling
if i<1
    i=1;
elseif i>length(list{1})
    i=length(list{1});
end
%% Obtaining the information from screenshots of DIGION

img=char(list{1}(i));
if i==1
   if strcmp(img(8:11),'0015')
    d_digion=true;
   end
end
I=imread([dir img]);
I2=I(:,:,3);
coeff=I2==255;
I2(~coeff)=0;
Ib=imbinarize(I2);
[m,n]=find(Ib==true);
%%
% Creating relationship pixel-frequency:
% 1 pixel w/ ~0.543% growth;
% NOTE: This will be improved for any resolution of the image.
Equiv_f=round(1.0054295.^(0:616),2); % 617 => pixel range
%%
% and pixel - height (0 to 100 w/ 56 equally spaced steps)
Equiv_h=[];
for j=0:7
    aux=linspace(0,100,57);
    Equiv_h=[Equiv_h aux(1:(end-1))+100.*j]; %#ok
end
Equiv_h=fliplr(round(Equiv_h,2)); %because is in reverse
%% M(3000) Calculation
VH_mf=[200 250 300 350 400:100:700];
for z=1:length(VH_mf)
    VH_MF(z)=find(Equiv_h==VH_mf(z))+31;
end
MUF=[4.55 4.04 3.65 3.33 3.08 2.69 2.4 2.2 2.04];
Equiv_MF=fliplr(Equiv_f(1:end));

mf1=find(Equiv_MF==4.55); mf2=find(Equiv_MF==4.04);
mf3=find(Equiv_MF==3.65); mf4=find(Equiv_MF==3.33);
mf5=find(Equiv_MF==3.08); mf6=find(Equiv_MF==2.69);
mf7=find(Equiv_MF==2.4); mf8=find(Equiv_MF==2.2);
MF=[mf1,mf2,mf3,mf4,mf5,mf6,mf7,mf8];
%% Instructions
if control==0
fprintf('Press the button that corresponds to the scaling variable \n')
fprintf('foE: F1; foF: F2; foF1: F3; fmin: F4 \n')
fprintf('fEs: F5; h''E: F6; h''F: F7; h''F2: F8; \nM3000: F9 \n')
fprintf('\nFor plot frequency, F11 \nFor V. Height, F12\n')
fprintf('\nPress ''Escape'' to exit\n')
input('\n(Press return key to continue) \n','s')
control=1;
end
%% Figure part

fig=figure(1);cla
if control2
set(fig, 'Position', get(0, 'Screensize'));
control2=0;
end

%% Callback function for key press / release
set(fig,'KeyPressFcn',@ctrlmode1,'KeyReleaseFcn',@ctrlmode2)


%%
plot(n,m,'.k'),hold on
set(gca,'Position',[0.1500 0.1100 0.6750 0.8150]);
title(['Ionogram ' img(5:6) '-' img(3:4)...
    '-20' img(1:2) ' ' img(8:9) ':' img(10:11)  ])
axis ij
axis([41 617 31 479])
%x-axis
ax1=106; ax2=170; ax3=234; ax4=298;
ax5=362; ax6=426; ax7=490; ax8=554;
xticks([ax1,ax2,ax3,ax4,ax5,ax6,ax7,ax8,ax8+63]);
xticklabels({'1.41','2.0','2.83','4.0','5.66','8.0'...
    ,'11.31','16','22.5'});
xlabel('Frequency (MHz)')
%y-axis
ay1=87; ay2=143; ay3=199; ay4=255;
ay5=311; ay6=367; ay7=423;
yticks([ay1,ay2,ay3,ay4,ay5,ay6,ay7]);
yticklabels({'700','600','500','400','300','200'...
    ,'100'});
ylabel('Virtual Height (km)')


%% Cursor part and scaling itself
go=true;
while go
    if contfig
    if ~isempty(databox) %#ok
        delete(databox)
    end
    val_show=[foE(i) foF(i) foF1(i) fmin(i) fEs(i) hE(i) hF(i) hF2(i) M3000(i)];
    lett_show={QDfoE(i,:),QDfoF(i,:),QDfoF1(i,:),...
    QDfmin(i,:),QDfEs(i,:),QDhE(i,:),QDhF(i,:),QDhF2(i,:),QDM3000(i,:)};
    i_aux.n=val_show;
    letvalues=lett_show;
    
    databox=annotation('textbox',[0.01 0.675 0.15 0.25],...
       'Interpreter','latex',...
       'String',...
       {['foE\quad: \quad ' num2str(i_aux.n(1),'%5.2f') ' ' letvalues{1,1}],...
       ['foF\quad: \quad ' num2str(i_aux.n(2),'%5.2f') ' ' letvalues{1,2}],...
       ['foF1 : \quad ' num2str(i_aux.n(3),'%5.2f') ' ' letvalues{1,3}],...
       ['fmin : \quad ' num2str(i_aux.n(4),'%5.2f') ' ' letvalues{1,4}],...
       ['fEs\quad: \quad ' num2str(i_aux.n(5),'%5.2f') ' ' letvalues{1,5}],...
       ['h''E\quad: \quad ' num2str(i_aux.n(6),'%6.2f') ' ' letvalues{1,6}],...
       ['h''F\quad: \quad ' num2str(i_aux.n(7),'%6.2f') ' ' letvalues{1,7}],...
       ['h''F2 : \quad ' num2str(i_aux.n(8),'%6.2f') ' ' letvalues{1,8}],...
       ['M3000:\quad ' num2str(i_aux.n(9),'%6.2f') ' ' letvalues{1,9}]},...
       'EdgeColor','none');
    end
    jk=waitforbuttonpress;
    if ~jk
        continue;
    end
    value=get(gcf,'CurrentKey');
    step=1;
    
    set(gca,'Position',[0.1500 0.1100 0.6750 0.8150]);
    %%
    switch value
%% foE
        case 'f1'
            ct1=true;
            if i==1 || ~exist('l1','var')
                l1=129;
            end
            hold on
            cla;
            plot(n,m,'.k')
            ex=Equiv_f(l1-41)+(fB/2);
            [~,l1x]=min(abs(Equiv_f-ex));
            plot(ones(1,100).*l1,linspace(31,479),'g')
            plot(ones(1,100).*(l1x+41),linspace(31,479),'g--')
            if ~isnan(foE(i))|| length(find(QDfoE(i,:)==' '))<2
                text(30,10,'foE*','FontSize',12,'FontWeight','bold')
            else
                text(30,10,'foE','FontSize',12,'FontWeight','bold')
            end
            while ct1
                waitforbuttonpress;
                val1=get(gcf,'CurrentKey');
                switch val1
                case 'rightarrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'foE','FontSize',12,'FontWeight','bold')
                    l1=l1+step;
                    if l1>617
                        l1=617;
                    elseif l1<42
                        l1=42;
                    end
                    ex=Equiv_f(l1-41)+(fB/2);
                    [~,l1x]=min(abs(Equiv_f-ex));
                    plot(ones(1,100).*l1,linspace(31,479),'g')
                    plot(ones(1,100).*(l1x+41),linspace(31,479),'g--')
                    text(80,10,num2str(Equiv_f(l1-41)),'FontSize',12,'FontWeight','bold')
                case 'leftarrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'foE','FontSize',12,'FontWeight','bold')
                    l1=l1-step;
                    if l1>617
                        l1=617;
                    elseif l1<42
                        l1=42;
                    end
                    ex=Equiv_f(l1-41)+(fB/2);
                    [~,l1x]=min(abs(Equiv_f-ex));
                    plot(ones(1,100).*l1,linspace(31,479),'g')
                    plot(ones(1,100).*(l1x+41),linspace(31,479),'g--')
                    text(80,10,num2str(Equiv_f(l1-41)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    try
                        foE(i,:)=Equiv_f(l1-41);
                    catch
                        foE(i,:)=NaN;
                    end
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDfoE(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfoE(i,:)=QD;
                    end
                    end
                    ct1=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct1=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1); 
                    if ~isempty(qd)
                    QD=qd{1,1};
                    foE(i)=NaN;
                    if size(QD,2)==1
                        QDfoE(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfoE(i,:)=QD;
                    end
                    end
                    ct1=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% foF
        case 'f2'
            ct2=true;
            if i==1 || ~exist('l2','var')
                l2=234;
            end
            hold on
            cla;
            plot(n,m,'.k')
            ex=Equiv_f(l2-41)+(fB/2);
            [~,l2x]=min(abs(Equiv_f-ex));
            plot(ones(1,100).*l2,linspace(31,479),'r')
            plot(ones(1,100).*(l2x+41),linspace(31,479),'r--')
            if ~isnan(foF(i))|| length(find(QDfoF(i,:)==' '))<2
                text(30,10,'foF*','FontSize',12,'FontWeight','bold')
            else
                text(30,10,'foF','FontSize',12,'FontWeight','bold')
            end
            while ct2
                waitforbuttonpress;
                val1=get(gcf,'CurrentKey');
                switch val1
                case 'rightarrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'foF','FontSize',12,'FontWeight','bold')
                    l2=l2+step;
                    if l2>617
                        l2=617;
                    elseif l2<42
                        l2=42;
                    end
                    ex=Equiv_f(l2-41)+(fB/2);
                    [~,l2x]=min(abs(Equiv_f-ex));
                    plot(ones(1,100).*l2,linspace(31,479),'r')
                    plot(ones(1,100).*(l2x+41),linspace(31,479),'r--')
                    text(80,10,num2str(Equiv_f(l2-41)),'FontSize',12,'FontWeight','bold')
                case 'leftarrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'foF','FontSize',12,'FontWeight','bold')
                    l2=l2-step;
                    if l2>617
                        l2=617;
                    elseif l2<42
                        l2=42;
                    end
                    ex=Equiv_f(l2-41)+(fB/2);
                    [~,l2x]=min(abs(Equiv_f-ex));
                    plot(ones(1,100).*l2,linspace(31,479),'r')
                    plot(ones(1,100).*(l2x+41),linspace(31,479),'r--')
                    text(80,10,num2str(Equiv_f(l2-41)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1); 
                    if ~isempty(qd)
                    try
                        foF(i,:)=Equiv_f(l2-41);
                    catch
                        foF(i,:)=NaN;
                    end
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDfoF(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfoF(i,:)=QD;
                    end
                    end
                    ct2=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct2=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    foF(i)=NaN;
                     QD=qd{1,1};
                    if size(QD,2)==1
                        QDfoF(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfoF(i,:)=QD;
                    end
                    end
                    ct2=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% foF1
        case 'f3'            
            ct3=true;
            if i==1 || ~exist('l3','var')
                l3=234;
            end
            hold on
            cla;
            plot(n,m,'.k')
            ex=Equiv_f(l3-41)+(fB/2);
            [~,l3x]=min(abs(Equiv_f-ex));
            plot(ones(1,100).*l3,linspace(31,479),'color',[0.75 0 0])
            plot(ones(1,100).*(l3x+41),linspace(31,479),'--','color',[0.75 0 0])
            if ~isnan(foF1(i))||length(find(QDfoF1(i,:)==' '))<2
                text(20,10,'foF1*','FontSize',12,'FontWeight','bold')
            else
                text(20,10,'foF1','FontSize',12,'FontWeight','bold')
            end
            while ct3
                waitforbuttonpress;
                val3=get(gcf,'CurrentKey');
                switch val3
                case 'rightarrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'foF1','FontSize',12,'FontWeight','bold')
                    l3=l3+step;
                    if l3>617
                        l3=617;
                    elseif l3<42
                        l3=42;
                    end
                    ex=Equiv_f(l3-41)+(fB/2);
                    [~,l3x]=min(abs(Equiv_f-ex));
                    plot(ones(1,100).*l3,linspace(31,479),'color',[0.75 0 0])
                    plot(ones(1,100).*(l3x+41),linspace(31,479),'--','color',[0.75 0 0])
                    text(80,10,num2str(Equiv_f(l3-41)),'FontSize',12,'FontWeight','bold')
                case 'leftarrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'foF1','FontSize',12,'FontWeight','bold')
                    l3=l3-step;
                    if l3>617
                        l3=617;
                    elseif l3<42
                        l3=42;
                    end
                    ex=Equiv_f(l3-41)+(fB/2);
                    [~,l3x]=min(abs(Equiv_f-ex));
                    plot(ones(1,100).*l3,linspace(31,479),'color',[0.75 0 0])
                    plot(ones(1,100).*(l3x+41),linspace(31,479),'--','color',[0.75 0 0])
                    text(80,10,num2str(Equiv_f(l3-41)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    try
                        foF1(i,:)=Equiv_f(l3-41);
                    catch
                        foF1(i,:)=NaN;
                    end
                     QD=qd{1,1};
                    if size(QD,2)==1
                        QDfoF1(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfoF1(i,:)=QD;
                    end
                    end
                    ct3=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct3=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    foF1(i)=NaN;
                     QD=qd{1,1};
                    if size(QD,2)==1
                        QDfoF1(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfoF1(i,:)=QD;
                    end
                    end
                    ct3=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% fmin
        case 'f4'
            ct4=true;
            if i==1 || ~exist('l4','var')
                l4=117;
            end
            hold on
            cla;
            plot(n,m,'.k')
            plot(ones(1,100).*l4,linspace(255,479),'b')
            if ~isnan(fmin(i))||length(find(QDfmin(i,:)==' '))<2
                text(20,10,'fmin*','FontSize',12,'FontWeight','bold')
            else
                text(20,10,'fmin','FontSize',12,'FontWeight','bold')
            end
            while ct4
                waitforbuttonpress;
                val4=get(gcf,'CurrentKey');
                switch val4
                case 'rightarrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'fmin','FontSize',12,'FontWeight','bold')
                    l4=l4+step;
                    if l4>617
                        l4=617;
                    elseif l4<42
                        l4=42;
                    end
                    plot(ones(1,100).*l4,linspace(255,479),'b')
                    text(80,10,num2str(Equiv_f(l4-41)),'FontSize',12,'FontWeight','bold')
                case 'leftarrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'fmin','FontSize',12,'FontWeight','bold')
                    l4=l4-step;
                    if l4>617
                        l4=617;
                    elseif l4<42
                        l4=42;
                    end
                    plot(ones(1,100).*l4,linspace(255,479),'b')
                    text(80,10,num2str(Equiv_f(l4-41)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    try
                        fmin(i,:)=Equiv_f(l4-41);
                    catch
                        fmin(i,:)=NaN;
                    end
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDfmin(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfmin(i,:)=QD;
                    end
                    end
                    ct4=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct4=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    fmin(i)=NaN;
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDfmin(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfmin(i,:)=QD;
                    end
                    end
                    ct4=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% fEs
        case 'f5'
            ct5=true;
            if i==1 || ~exist('l5','var')
                l5=117;
            end
            hold on
            cla;
            plot(n,m,'.k')
            plot(ones(1,100).*l5,linspace(255,479),'c')
            if ~isnan(fEs(i)) || length(find(QDfEs(i,:)==' '))<2
                text(20,10,'fEs*','FontSize',12,'FontWeight','bold')
            else
                text(20,10,'fEs','FontSize',12,'FontWeight','bold')
            end
            while ct5
                waitforbuttonpress;
                val5=get(gcf,'CurrentKey');
                switch val5
                case 'rightarrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'fEs','FontSize',12,'FontWeight','bold')
                    l5=l5+step;
                    if l5>617
                        l5=617;
                    elseif l5<42
                        l5=42;
                    end
                    plot(ones(1,100).*l5,linspace(255,479),'c')
                    text(80,10,num2str(Equiv_f(l5-41)),'FontSize',12,'FontWeight','bold')
                case 'leftarrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'fEs','FontSize',12,'FontWeight','bold')
                    l5=l5-step;
                    if l5>617
                        l5=617;
                    elseif l5<42
                        l5=42;
                    end
                    plot(ones(1,100).*l5,linspace(255,479),'c')
                    text(80,10,num2str(Equiv_f(l5-41)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    try
                        fEs(i,:)=Equiv_f(l5-41);
                    catch
                        fEs(i,:)=NaN;
                    end
                     QD=qd{1,1};
                    if size(QD,2)==1
                        QDfEs(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfEs(i,:)=QD;
                    end
                    end
                    ct5=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct5=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    fEs(i)=NaN;
                     QD=qd{1,1};
                    if size(QD,2)==1
                        QDfEs(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDfEs(i,:)=QD;
                    end
                    end
                    ct5=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% h'E
        case 'f6'
            ct6=true;
            if i==1 || ~exist('l6','var')
                l6=423;
            end
            hold on
            cla;
            plot(n,m,'.k')
            plot(linspace(41,417),ones(1,100).*l6,'Color',[0.5 0.5 0.5])
            plot(linspace(41,417),ones(1,100).*(479-(479-l6)*2),'Color',[0.5 0.5 0.5])
            if ~isnan(hE(i))|| length(find(QDhE(i,:)==' '))<2
                text(30,10,'h''E*','FontSize',12,'FontWeight','bold')
            else
                text(30,10,'h''E','FontSize',12,'FontWeight','bold')
            end
            while ct6
                waitforbuttonpress;
                val6=get(gcf,'CurrentKey');
                switch val6
                case 'uparrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'h''E','FontSize',12,'FontWeight','bold')
                    l6=l6-step;
                    if l6>length(Equiv_h)+31
                        l6=length(Equiv_h)+31;
                    elseif l6<32
                        l6=32;
                    end
                    plot(linspace(41,417),ones(1,100).*l6,'Color',[0.5 0.5 0.5])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l6)*2),'Color',[0.5 0.5 0.5])
                    text(80,10,num2str(Equiv_h(l6-31)),'FontSize',12,'FontWeight','bold')
                case 'downarrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'h''E','FontSize',12,'FontWeight','bold')
                    l6=l6+step;
                    if l6>length(Equiv_h)+31
                        l6=length(Equiv_h)+31;
                    elseif l6<32
                        l6=32;
                    end
                    plot(linspace(41,417),ones(1,100).*l6,'Color',[0.5 0.5 0.5])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l6)*2),'Color',[0.5 0.5 0.5])
                    text(80,10,num2str(Equiv_h(l6-31)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    try
                        hE(i,:)=Equiv_h(l6-31);
                    catch
                        hE(i,:)=NaN;
                    end
                     QD=qd{1,1};
                    if size(QD,2)==1
                        QDhE(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDhE(i,:)=QD;
                    end
                    end
                    ct6=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct6=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                    hE(i)=NaN;
                     QD=qd{1,1};
                    if size(QD,2)==1
                        QDhE(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDhE(i,:)=QD;
                    end
                    end
                    ct6=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% h'F
        case 'f7'
            ct7=true;
            if i==1 || ~exist('l7','var')
                l7=367;
            end
            hold on
            cla;
            plot(n,m,'.k')
            plot(linspace(41,417),ones(1,100).*l7,'Color',[0 0.75 0.75])
            plot(linspace(41,417),ones(1,100).*(479-(479-l7)*2),'Color',[0 0.75 0.75])
            plot(linspace(41,417),ones(1,100).*(479-(479-l7)*3),'Color',[0 0.75 0.75])
            if ~isnan(hF(i))|| length(find(QDhF(i,:)==' '))<2
                text(30,10,'h''F*','FontSize',12,'FontWeight','bold')
            else
                text(30,10,'h''F','FontSize',12,'FontWeight','bold')
            end
            while ct7
                waitforbuttonpress;
                val7=get(gcf,'CurrentKey');
                switch val7
                case 'uparrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'h''F','FontSize',12,'FontWeight','bold')
                    l7=l7-step;
                    if l7>length(Equiv_h)+31
                        l7=length(Equiv_h)+31;
                    elseif l7<32
                        l7=32;
                    end
                    plot(linspace(41,417),ones(1,100).*l7,'Color',[0 0.75 0.75])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l7)*2),'Color',[0 0.75 0.75])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l7)*3),'Color',[0 0.75 0.75])
                    text(80,10,num2str(Equiv_h(l7-31)),'FontSize',12,'FontWeight','bold')
                case 'downarrow'
                    cla;
                    plot(n,m,'.k')
                    text(30,10,'h''F','FontSize',12,'FontWeight','bold')
                    l7=l7+step;
                    if l7>length(Equiv_h)+31
                        l7=length(Equiv_h)+31;
                    elseif l7<32
                        l7=32;
                    end
                    plot(linspace(41,417),ones(1,100).*l7,'Color',[0 0.75 0.75])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l7)*2),'Color',[0 0.75 0.75])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l7)*3),'Color',[0 0.75 0.75])
                    text(80,10,num2str(Equiv_h(l7-31)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1); 
                    if ~isempty(qd)
                    try
                        hF(i,:)=Equiv_h(l7-31);
                    catch
                        hF(i,:)=NaN;
                    end
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDhF(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDhF(i,:)=QD;
                    end
                    end
                    ct7=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct7=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1); 
                    if ~isempty(qd)
                    hF(i)=NaN;
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDhF(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDhF(i,:)=QD;
                    end
                    end
                    ct7=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% h'F2
        case 'f8'
            ct8=true;
            if i==1 || ~exist('l8','var')
                l8=367;
            end
            hold on
            cla;
            plot(n,m,'.k')
            plot(linspace(41,417),ones(1,100).*l8,'Color',[0 0.5 0.5])
            plot(linspace(41,417),ones(1,100).*(479-(479-l8)*2),'Color',[0 0.5 0.5])
            plot(linspace(41,417),ones(1,100).*(479-(479-l8)*3),'Color',[0 0.5 0.5])
            if ~isnan(hF2(i))|| length(find(QDhF2(i,:)==' '))<2
                text(20,10,'h''F2*','FontSize',12,'FontWeight','bold')
            else
                text(20,10,'h''F2','FontSize',12,'FontWeight','bold')
            end
            while ct8
                waitforbuttonpress;
                val8=get(gcf,'CurrentKey');
                switch val8
                case 'uparrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'h''F2','FontSize',12,'FontWeight','bold')
                    l8=l8-step;
                    if l8>length(Equiv_h)+31
                        l8=length(Equiv_h)+31;
                    elseif l8<32
                        l8=32;
                    end
                    plot(linspace(41,417),ones(1,100).*l8,'Color',[0 0.5 0.5])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l8)*2),'Color',[0 0.5 0.5])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l8)*3),'Color',[0 0.5 0.5])
                    text(80,10,num2str(Equiv_h(l8-31)),'FontSize',12,'FontWeight','bold')
                case 'downarrow'
                    cla;
                    plot(n,m,'.k')
                    text(20,10,'h''F2','FontSize',12,'FontWeight','bold')
                    l8=l8+step;
                    if l8>length(Equiv_h)+31
                        l8=length(Equiv_h)+31;
                    elseif l8<32
                        l8=32;
                    end
                    plot(linspace(41,417),ones(1,100).*l8,'Color',[0 0.5 0.5])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l8)*2),'Color',[0 0.5 0.5])
                    plot(linspace(41,417),ones(1,100).*(479-(479-l8)*3),'Color',[0 0.5 0.5])
                    text(80,10,num2str(Equiv_h(l8-31)),'FontSize',12,'FontWeight','bold')
                case 'return'
                    qd=inputdlg(msg1); 
                    if ~isempty(qd)
                    try
                        hF2(i,:)=Equiv_h(l8-31);
                    catch
                        hF2(i,:)=NaN;
                    end
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDhF2(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDhF2(i,:)=QD;
                    end
                    end
                    ct8=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct8=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1); 
                    if ~isempty(qd)
                    hF2(i)=NaN;
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDhF2(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDhF2(i,:)=QD;
                    end 
                    end
                    ct8=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
%% M3000
        case 'f9'
            ct9=true;
            l9=-20;
            hold on
            cla;
            plot(n,m,'.k')
            plot(MF+l9,VH_MF,'m')
            if ~isnan(M3000(i))|| length(find(QDM3000(i,:)==' '))<2
                text(-10,10,'M3000*','FontSize',12,'FontWeight','bold')
            else
                text(-10,10,'M3000','FontSize',12,'FontWeight','bold')
            end
            while ct9
                waitforbuttonpress;
                val9=get(gcf,'CurrentKey');
                l2=find(foF(i)==Equiv_f)+41;
                switch val9
                case 'rightarrow'
                    cla;
                    plot(n,m,'.k')
                    text(-10,10,'M3000','FontSize',12,'FontWeight','bold')
                    l9=l9+step;
                    if mf8+l9>617
                        l9=617-mf8;
                    elseif mf1+l9<42
                        l9=42-mf1;
                    end
                    plot(MF+l9,VH_MF,'m')
                    if exist('l2','var')
                    text(80,10,num2str(Equiv_MF(l2-l9)),'FontSize',12,'FontWeight','bold')
                    end
                case 'leftarrow'
                    cla;
                    plot(n,m,'.k')
                    text(-10,10,'M3000','FontSize',12,'FontWeight','bold')
                    l9=l9-step;
                    if mf8+l9>617
                        l9=617-mf8;
                    elseif mf1+l9<42
                        l9=42-mf1;
                    end
                    plot(MF+l9,VH_MF,'m')
                    if exist('l2','var')
                    text(80,10,num2str(Equiv_MF(l2-l9)),'FontSize',12,'FontWeight','bold')
                    end
                case 'return'
                    qd=inputdlg(msg1);
                    if ~isempty(qd)
                        QD=qd{1,1};
                        if size(QD,2)==1
                            QDM3000(i,:)=[' ' QD];
                        elseif ~isempty(QD)
                            QDM3000(i,:)=QD;
                        else
                            QDM3000(i,:)=QDfoF(i,:);
                        end
                        try
                            M3000(i,:)=Equiv_MF(l2-l9);
                        catch
                            M3000(i,:)=NaN;
                        end
                    end
                    ct9=false;
                    cla;
                    plot(n,m,'.k')
                case {'escape','f1','f2','f3','f4','f5','f6','f7','f8','f9'}
                    ct9=false;
                    cla;
                    plot(n,m,'.k')
                case 'delete'
                    qd=inputdlg(msg1); 
                    if ~isempty(qd)
                    M3000(i)=NaN;
                    QD=qd{1,1};
                    if size(QD,2)==1
                        QDM3000(i,:)=[' ' QD];
                    elseif ~isempty(QD)
                        QDM3000(i,:)=QD;
                    else
                        QDM3000(i,:)=QDfoF(i,:);
                    end
                    end
                    ct9=false;
                    cla;
                    plot(n,m,'.k')
                end
            end
        case 'uparrow'
            i=i-1;
            go=false;
        case 'downarrow'
            i=i+1;
            go=false;
        case 'f11'
            hr=linspace(0,23.75,96);
            fig=figure(2); clf
            plot(hr,foE,'go-','MarkerSize',5), hold on
            plot(hr,foF,'rs-','MarkerSize',5)
            plot(hr,foF1,'d-','MarkerSize',5,'color',[0.75 0 0])
            plot(hr,fmin,'b^-','MarkerSize',5)
            plot(hr,fEs,'cx-','MarkerSize',5)
            plot(hr,M3000,'*-m','MarkerSize',5)
            hold off
            xlim([0,24])
            ylim([0 11])
            xticks([0,4,8,12,16,20,24]);
            xticklabels({'20','00','04','08','12','16','20'})
            xlabel('Hour (LTC -4:00)')
            ylabel('Frequency (MHz)')
            set(gca(fig),'XMinorTick','on','YMinorTick','on');
            legend('foE','foF','foF1','fmin','fEs','M3000','Location','Northwest')
            title(['Freq. Data ' img(5:6) '-' img(3:4)...
                    '-20' img(1:2) ])
            pause;
            close;
         case 'f12'
            Hr=linspace(0,23.75,96);
            figure(2),clf
            plot(Hr,hE,'o-','MarkerSize',5,'Color',[0.75 0.75 0.75]), hold on
            plot(Hr,hF,'o-','MarkerSize',5,'Color',[0 0.75 0.75])
            plot(Hr,hF2,'o-','MarkerSize',5,'Color',[0 0.5 0.5])
            hold off
            xlim([0,24])
            ylim([80 400])
            xticks([0,4,8,12,16,20,24]);
            xticklabels({'20','00','04','08','12','16','20'})
            xlabel('Hour (LTC -4:00)')
            ylabel('Virtual height (km)')
            legend('h''E','h''F','h''F2','Location','Northwest')
            set(gca,'XMinorTick','on','YMinorTick','on');
            title(['V. Height Data ' img(5:6) '-' img(3:4)...
                    '-20' img(1:2) ])
            pause;
            close;
         case 'escape'
            go=false;
            scaling=false;
         case 'g'
            fB_old=fB;
            fB=inputdlg(['fB determined as ' num2str(fB) '. Select the new value (`Cancel` won''t change it)']);
            if isempty(fB) || isempty(fB{1})
                fB=fB_old;
            else
                fB=str2num(fB{1});
            end            
   end
end
end
close;

%% Ask about saving scaling data
saving=questdlg(['Do you want to save changes on ' dd '/' mm '/' yy ' scaled data?']...
    ,['DISS v.' version],'Yes','No','Yes');
if strcmp(saving,'No')
   return; 
end

%% Creating Directory to save scaled data
if (exist('ScaledData','dir')==0)
    mkdir('ScaledData') 
end
%% Creating a column with time (hh:mm)

Hr2=repmat(0:23,4,1);
Hr=reshape(Hr2,96,1);
Min=repmat([0 15 30 45]',24,1);

if d_digion
    Hr=[Hr(2:end);Hr(1)];
    Min=[Min(2:end);Min(1)];
end

%% Creating numerical data archive and saving it
id_data=fopen(['ScaledData/' yy mm dd '.dat'],'w');

header1=['%Scaled Data from 20' yy '-' mm '-' dd ' ionograms. Scaled on: ' date];
header2={'%Hr','Min','foE','foF','foF1','fmin','fEs','h''E','h''F','h''F2','M3000'};
fprintf(id_data,'%s\n',header1);
for h=1:length(header2)
   switch h
       case 1
            fprintf(id_data,'%3s',header2{h});
       case 2
            fprintf(id_data,'%4s',header2{h});
       case {3,4,5,6,7}
            fprintf(id_data,'%6s',header2{h});
       case {8,9,10}
            fprintf(id_data,'%7s',header2{h});
       case 11
            fprintf(id_data,'%6s',header2{h});
   end
end
fprintf(id_data,'\n');
for k=1:96
    fprintf(id_data,'%2d %3d %5.2f %5.2f %5.2f %5.2f %5.2f %6.2f %6.2f %6.2f %5.2f\n',...
        Hr(k),Min(k),foE(k),foF(k),foF1(k),fmin(k),fEs(k),hE(k),hF(k),hF2(k),M3000(k));
end

%% Creating Letters Data archive and saving it

id_data2=fopen(['ScaledData/' yy mm dd '_letters.dat'],'w');

header1=['Scaled Data from 20' yy '-' mm '-' dd ' ionograms. Scaled on: ' date];
header2={'Hr','Min','foE','foF','foF1','fmin','ftEs','h''E','h''F','h''F2','M3000'};
fprintf(id_data2,'%s\n',header1);
for h=1:length(header2)
    switch h
        case 1
        fprintf(id_data2,'%2s',header2{h});
        case 2
        fprintf(id_data2,'%4s',header2{h});
        case {3,4,5,6,7,8,9,10}
        fprintf(id_data2,'%5s',header2{h});
        case 11
        fprintf(id_data2,'%6s',header2{h});
    end
end
fprintf(id_data2,'\n');
for k=1:96
    fprintf(id_data2,'%2d %3d,%4s,%4s,%4s,%4s,%4s,%4s,%4s,%4s,%5s\n',...
        Hr(k),Min(k),QDfoE(k,:),QDfoF(k,:),QDfoF1(k,:),QDfmin(k,:),...
        QDfEs(k),QDhE(k,:),QDhF(k,:),QDhF2(k,:),QDM3000(k,:));
end

%% Callback functions
%  it's implementation begins on v. 0.0.4
%  (Include switch to amplify the use)
function ctrlmode1(~,KeyPress)
    global step contfig databox
    switch KeyPress.Key 
       case 'control'
           step=8;
       case 'tab'
           if ~contfig
               contfig=~contfig;
           else
               delete(databox)
               contfig=~contfig;
           end
    end
end

function ctrlmode2(~,KeyPress)
    global step
    switch KeyPress.Key 
       case 'control'
           step=1;
    end
end